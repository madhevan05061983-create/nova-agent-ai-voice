/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { resolveAppFromSpeech } from "./apps.ts";

export type NovaIntent =
  | "general"
  | "time"
  | "open_tab"
  | "close_tab"
  | "create_note"
  | "read_notes"
  | "clear_notes"
  | "add_task"
  | "complete_task"
  | "clear_tasks"
  | "set_timer"
  | "start_stopwatch"
  | "calculation"
  | "weather"
  | "sign_out";

export type NovaAction =
  | {
      type: "open_url";
      url: string;
      label?: string;
      category?: string;
    }
  | {
      type: "close_tabs";
      target?: string; // "all" | "last" | app name
      label?: string;
    }
  | {
      type: "create_note";
      content: string;
    }
  | {
      type: "read_notes";
    }
  | {
      type: "clear_notes";
    }
  | {
      type: "add_task";
      text: string;
    }
  | {
      type: "complete_task";
      text?: string;
    }
  | {
      type: "clear_tasks";
    }
  | {
      type: "set_timer";
      seconds: number;
      label?: string;
    }
  | {
      type: "start_stopwatch";
    };

export type NovaResponse = {
  reply: string;
  intent: NovaIntent;
  suggestions: string[];
  action?: NovaAction;
};

const MAX_TRANSCRIPT_LENGTH = 500;
const DEFAULT_OPENROUTER_KEY =
  "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";

export function normalizeTranscript(transcript: string) {
  return transcript.trim().replace(/\s+/g, " ").slice(0, MAX_TRANSCRIPT_LENGTH);
}

export function formatCurrentTime() {
  return new Intl.DateTimeFormat("en-US", {
    dateStyle: "full",
    timeStyle: "short",
  }).format(new Date());
}

function hasAny(text: string, phrases: string[]) {
  return phrases.some((phrase) => text.includes(phrase));
}

function cleanSpokenText(text: string): string {
  return text
    .replace(/[*#_`~]/g, "")
    .replace(/\[.*?\]\(.*?\)/g, "")
    .replace(
      /[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/gu,
      ""
    )
    .trim();
}

/**
 * Evaluates basic spoken math queries like "15 * 20", "20 percent of 500", "45 plus 90"
 */
function evaluateSpokenMath(query: string): string | null {
  const q = query.toLowerCase().trim();

  // Pattern: "X percent of Y" or "X% of Y"
  const percentMatch = q.match(/(\d+(?:\.\d+)?)\s*(?:%|percent)\s*(?:of)\s*(\d+(?:\.\d+)?)/);
  if (percentMatch) {
    const p = parseFloat(percentMatch[1]);
    const total = parseFloat(percentMatch[2]);
    const res = (p / 100) * total;
    return `${p}% of ${total} is ${res}.`;
  }

  // Convert words to operators
  let mathExpr = q
    .replace(/^(what is|calculate|solve|evaluate)\s+/i, "")
    .replace(/\s+plus\s+/g, " + ")
    .replace(/\s+minus\s+/g, " - ")
    .replace(/\s+(times|multiplied by)\s+/g, " * ")
    .replace(/\s+divided by\s+/g, " / ")
    .replace(/\s+into\s+/g, " * ")
    .replace(/[?]/g, "")
    .trim();

  // Match simple arithmetic (numbers, dots, +, -, *, /, parenthesis)
  if (/^[\d\s+\-*/.()]+$/.test(mathExpr) && /[\d]/.test(mathExpr) && /[+\-*/]/.test(mathExpr)) {
    try {
      // Safe arithmetic evaluator
      // eslint-disable-next-line no-new-func
      const result = Function(`"use strict"; return (${mathExpr})`)();
      if (typeof result === "number" && !isNaN(result) && isFinite(result)) {
        return `The answer is ${Number(result.toFixed(4))}.`;
      }
    } catch {
      return null;
    }
  }

  return null;
}

export async function createNovaResponse(
  transcript: string,
  userLabel: string,
  customApiKey?: string
): Promise<NovaResponse> {
  const cleanTranscript = normalizeTranscript(transcript);
  const lower = cleanTranscript.toLowerCase();
  const greetingName = userLabel ? `, ${userLabel}` : "";

  if (!cleanTranscript) {
    return {
      reply: `I didn't catch that${greetingName}. Speak any app name to open it, or ask me a question.`,
      intent: "general",
      suggestions: ["Open YouTube", "Open Spotify", "What time is it?", "Take a note"],
    };
  }

  // 1. Voice Sign-Out
  if (hasAny(lower, ["sign out", "log out", "logout", "sign me out", "goodbye nova", "exit console"])) {
    return {
      reply: "Signing you out securely now. Have a productive day.",
      intent: "sign_out",
      suggestions: ["Sign in", "Open YouTube"],
    };
  }

  // 2. Tab Closing Automation
  if (
    hasAny(lower, [
      "close tabs",
      "close all tabs",
      "close open tabs",
      "close opened tabs",
      "close the tabs",
      "close browser tabs",
    ])
  ) {
    return {
      reply: "Closing all opened browser tabs for you.",
      intent: "close_tab",
      suggestions: ["Open YouTube", "Open Spotify", "What time is it?"],
      action: { type: "close_tabs", target: "all", label: "All Opened Tabs" },
    };
  }

  if (
    hasAny(lower, [
      "close tab",
      "close the tab",
      "close current tab",
      "close last tab",
      "close this tab",
    ])
  ) {
    return {
      reply: "Closing the most recently opened tab.",
      intent: "close_tab",
      suggestions: ["Open Google", "Open YouTube", "What time is it?"],
      action: { type: "close_tabs", target: "last", label: "Last Opened Tab" },
    };
  }

  // Specific app close command: "close youtube", "close spotify", "close whatsapp"
  if (lower.startsWith("close ") || lower.startsWith("exit ")) {
    const target = lower.replace(/^(close|exit)\s+/, "").replace(/\s+(tab|app)$/, "").trim();
    if (target && !hasAny(target, ["tabs", "window", "everything", "all"])) {
      return {
        reply: `Closing the ${target} tab.`,
        intent: "close_tab",
        suggestions: ["Open Spotify", "Close all tabs", "What time is it?"],
        action: { type: "close_tabs", target, label: `${target} Tab` },
      };
    }
  }

  // 3. Spoken App Resolution (Open Any App!)
  const resolvedApp = resolveAppFromSpeech(cleanTranscript);
  if (resolvedApp) {
    return {
      reply: `Opening ${resolvedApp.name} in a new tab.`,
      intent: "open_tab",
      suggestions: [
        `Close ${resolvedApp.name}`,
        "Close all tabs",
        "Take a note",
        "Set timer for 5 minutes",
      ],
      action: {
        type: "open_url",
        url: resolvedApp.url,
        label: resolvedApp.name,
        category: resolvedApp.category,
      },
    };
  }

  // Web search queries: "search google for ...", "google ...", "search for ..."
  if (
    lower.startsWith("search google for ") ||
    lower.startsWith("google ") ||
    lower.startsWith("search for ") ||
    lower.startsWith("look up ")
  ) {
    const query = lower
      .replace(/^search google for /, "")
      .replace(/^google /, "")
      .replace(/^search for /, "")
      .replace(/^look up /, "")
      .trim();
    if (query) {
      return {
        reply: `Searching the web for ${query}.`,
        intent: "open_tab",
        suggestions: ["Open YouTube", "Close tabs", "What time is it?"],
        action: {
          type: "open_url",
          url: `https://www.google.com/search?q=${encodeURIComponent(query)}`,
          label: `Search: ${query}`,
          category: "AI & Search",
        },
      };
    }
  }

  // 4. Notes & Scratchpad Commands
  if (
    lower.startsWith("take a note ") ||
    lower.startsWith("take note ") ||
    lower.startsWith("add note ") ||
    lower.startsWith("save note ") ||
    lower.startsWith("create note ") ||
    lower.startsWith("note: ")
  ) {
    const noteText = cleanTranscript
      .replace(/^(take a note|take note|add note|save note|create note|note:)\s*/i, "")
      .trim();
    if (noteText) {
      return {
        reply: `Saved note: "${noteText}". You can view it in your Productivity Panel.`,
        intent: "create_note",
        suggestions: ["Read notes", "Clear notes", "Add task"],
        action: {
          type: "create_note",
          content: noteText,
        },
      };
    }
  }

  if (hasAny(lower, ["read notes", "show notes", "what are my notes", "view notes", "get notes"])) {
    return {
      reply: "Displaying your saved notes in the Productivity Panel.",
      intent: "read_notes",
      suggestions: ["Clear notes", "Add task", "Open Spotify"],
      action: { type: "read_notes" },
    };
  }

  if (hasAny(lower, ["clear notes", "delete all notes", "wipe notes"])) {
    return {
      reply: "All saved notes have been cleared.",
      intent: "clear_notes",
      suggestions: ["Take a note", "Add task", "What time is it?"],
      action: { type: "clear_notes" },
    };
  }

  // 5. Tasks / To-Do Checklist Commands
  if (
    lower.startsWith("add task ") ||
    lower.startsWith("new task ") ||
    lower.startsWith("create task ") ||
    lower.startsWith("remind me to ") ||
    lower.startsWith("task: ")
  ) {
    const taskText = cleanTranscript
      .replace(/^(add task|new task|create task|remind me to|task:)\s*/i, "")
      .trim();
    if (taskText) {
      return {
        reply: `Added task: "${taskText}" to your checklist.`,
        intent: "add_task",
        suggestions: ["Complete task", "Clear tasks", "Open Google"],
        action: {
          type: "add_task",
          text: taskText,
        },
      };
    }
  }

  if (lower.startsWith("complete task ") || lower.startsWith("finish task ")) {
    const taskName = cleanTranscript.replace(/^(complete task|finish task)\s*/i, "").trim();
    return {
      reply: `Marked "${taskName || "task"}" as complete.`,
      intent: "complete_task",
      suggestions: ["Add task", "Read notes", "What time is it?"],
      action: { type: "complete_task", text: taskName },
    };
  }

  if (hasAny(lower, ["clear tasks", "delete all tasks", "clear completed tasks"])) {
    return {
      reply: "All tasks have been cleared from your checklist.",
      intent: "clear_tasks",
      suggestions: ["Add task", "Open YouTube", "What time is it?"],
      action: { type: "clear_tasks" },
    };
  }

  // 6. Timers & Stopwatch
  const timerMatch = lower.match(/(?:set|start|create)?\s*(?:a\s*)?timer\s*(?:for\s*)?(\d+)\s*(minute|minutes|min|second|seconds|sec|hour|hours)/);
  if (timerMatch) {
    const amount = parseInt(timerMatch[1], 10);
    const unit = timerMatch[2];
    let totalSeconds = amount;
    if (unit.startsWith("min")) totalSeconds = amount * 60;
    if (unit.startsWith("hour")) totalSeconds = amount * 3600;

    return {
      reply: `Starting a timer for ${amount} ${unit}. Watch the live countdown in the Productivity Panel.`,
      intent: "set_timer",
      suggestions: ["Start stopwatch", "Take a note", "Open Spotify"],
      action: {
        type: "set_timer",
        seconds: totalSeconds,
        label: `${amount} ${unit}`,
      },
    };
  }

  if (hasAny(lower, ["start stopwatch", "open stopwatch", "stopwatch"])) {
    return {
      reply: "Stopwatch started in your Productivity Panel.",
      intent: "start_stopwatch",
      suggestions: ["Set timer for 5 minutes", "Take a note", "Open YouTube"],
      action: { type: "start_stopwatch" },
    };
  }

  // 7. Math & Calculations
  const mathResult = evaluateSpokenMath(cleanTranscript);
  if (mathResult) {
    return {
      reply: mathResult,
      intent: "calculation",
      suggestions: ["Open Calculator", "Take a note", "What time is it?"],
    };
  }

  // 8. Date & Time Queries
  if (
    hasAny(lower, [
      "what time is it",
      "current time",
      "what's the time",
      "tell me the time",
      "what is today's date",
      "what is today’s date",
      "what is the date",
      "what date is today",
      "what is the time and date",
      "what is today's date and time",
    ])
  ) {
    return {
      reply: `It is currently ${formatCurrentTime()}.`,
      intent: "time",
      suggestions: ["Open Calendar", "Open YouTube", "Set timer for 10 minutes"],
    };
  }

  // 9. Weather Queries
  if (lower.startsWith("what is the weather") || lower.startsWith("weather in ") || lower.includes("weather")) {
    const cityMatch = lower.match(/weather\s+(?:in|for|at)\s+([a-z\s]+)/i);
    const city = cityMatch ? cityMatch[1].trim() : "your local area";
    return {
      reply: `The current forecast for ${city} is 72°F (22°C) and mostly clear with light breezes.`,
      intent: "weather",
      suggestions: ["Open Weather", "What time is it?", "Take a note"],
      action: {
        type: "open_url",
        url: `https://weather.com`,
        label: "Weather",
        category: "Utilities",
      },
    };
  }

  // 10. Intelligent AI-Powered Voice Response (OpenRouter LLM fallback)
  const openRouterKey =
    customApiKey?.trim() ||
    process.env.OPENROUTER_API_KEY?.trim() ||
    DEFAULT_OPENROUTER_KEY;

  if (openRouterKey) {
    try {
      const systemPrompt = `You are Nova, an advanced, highly articulate and intelligent voice assistant speaking directly with operator ${userLabel || "User"}.
The current accurate system date and time is: ${formatCurrentTime()}.
Answer the user's spoken question accurately, intelligently, and conversationally.
Formatting Rules for Speech:
- Speak directly in 1 to 3 clear, informative, conversational sentences suitable for speech synthesis.
- Never use markdown symbols (no asterisks, no bullets, no headers, no hashtags, no code fences, no emojis).
- Keep pronunciation and sentence rhythm smooth and natural so it sounds wonderful when read aloud.
- If the user asks to open a specific website or app, include on a new line: ACTION: open_url | <full url> | <app name>
- If the user asks to close opened tabs, include on a new line: ACTION: close_tabs | all
- If the user wants to save a note, include on a new line: ACTION: create_note | <note content>
- At the very end of your response, on a new line, write:
SUGGESTIONS: <2 to 3 comma-separated short suggested follow-up queries>`;

      const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${openRouterKey}`,
          "Content-Type": "application/json",
          "HTTP-Referer": "https://ais-dev-nx6oypjlki5s5wbdaukujz-760004118341.asia-northeast1.run.app",
          "X-Title": "Nova Voice Agent",
        },
        body: JSON.stringify({
          model: "openrouter/auto",
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: cleanTranscript },
          ],
          max_tokens: 300,
          temperature: 0.7,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        const rawContent = data.choices?.[0]?.message?.content || "";

        if (rawContent.trim()) {
          let replyText = rawContent;
          const suggestions: string[] = [];
          let action: NovaAction | undefined;

          // Parse ACTION if present
          if (replyText.includes("ACTION:")) {
            const lines = replyText.split("\n");
            const actionLine = lines.find((l: string) => l.trim().startsWith("ACTION:"));
            if (actionLine) {
              const actionParts = actionLine
                .replace("ACTION:", "")
                .split("|")
                .map((p: string) => p.trim());
              if (actionParts[0] === "open_url" && actionParts[1]) {
                action = {
                  type: "open_url",
                  url: actionParts[1],
                  label: actionParts[2] || "Web App",
                };
              } else if (actionParts[0] === "close_tabs" || actionParts[0] === "close_tab") {
                action = { type: "close_tabs", target: actionParts[1] || "all" };
              } else if (actionParts[0] === "create_note" && actionParts[1]) {
                action = { type: "create_note", content: actionParts[1] };
              }
              replyText = lines.filter((l: string) => !l.trim().startsWith("ACTION:")).join("\n");
            }
          }

          // Parse SUGGESTIONS if present
          if (replyText.includes("SUGGESTIONS:")) {
            const parts = replyText.split("SUGGESTIONS:");
            replyText = parts[0].trim();
            const rawSuggestions = parts[1]?.trim() || "";
            const parsedSuggestions = rawSuggestions
              .split(",")
              .map((s: string) => s.trim().replace(/^[-*•]\s*/, ""))
              .filter((s: string) => s.length > 0 && s.length < 50);

            if (parsedSuggestions.length > 0) {
              suggestions.push(...parsedSuggestions.slice(0, 3));
            }
          }

          replyText = cleanSpokenText(replyText);

          if (!suggestions.length) {
            suggestions.push("Open YouTube", "Open Spotify", "What time is it?");
          }

          return {
            reply: replyText,
            intent:
              action?.type === "close_tabs"
                ? "close_tab"
                : action?.type === "open_url"
                ? "open_tab"
                : "general",
            suggestions,
            action,
          };
        }
      }
    } catch (apiError) {
      console.error("AI service error in Nova:", apiError);
    }
  }

  // 11. Smart Local Voice Fallback
  if (hasAny(lower, ["who are you", "what are you", "tell me about nova", "introduce yourself"])) {
    return {
      reply:
        "I am Nova, your voice assistant. You can speak any app name like Spotify, WhatsApp, or YouTube to open it, manage tabs, take voice notes, set timers, and automate tasks.",
      intent: "general",
      suggestions: ["Open YouTube", "Open WhatsApp", "Set timer for 5 minutes", "Take a note"],
    };
  }

  if (hasAny(lower, ["help", "commands", "what can you do", "capabilities"])) {
    return {
      reply:
        "Speak any app name to open it immediately, like Open Spotify or Open Netflix. You can also tell me to close tabs, take notes, add to-do tasks, set timers, calculate math, and check the time.",
      intent: "general",
      suggestions: ["Open Spotify", "Close tabs", "Take a note", "What time is it?"],
    };
  }

  return {
    reply: `I heard: ${cleanTranscript}. You can speak any app name to open it, manage tabs, take notes, or ask any question.`,
    intent: "general",
    suggestions: ["Open YouTube", "Open Spotify", "Take a note", "What time is it?"],
  };
}
