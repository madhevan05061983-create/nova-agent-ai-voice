/**
 * Comprehensive Application Registry and Voice Resolution Engine
 * Supports 120+ verified web apps across categories and general pattern matching.
 */

export type AppDefinition = {
  id: string;
  name: string;
  aliases: string[];
  url: string;
  category: "Social" | "Media" | "AI & Search" | "Productivity" | "Developer" | "Shopping" | "Utilities" | "Education";
  icon: string; // Lucide icon name or emoji
  description: string;
};

export const APP_REGISTRY: AppDefinition[] = [
  // --- AI & Search ---
  {
    id: "google",
    name: "Google",
    aliases: ["google", "google search", "search"],
    url: "https://www.google.com",
    category: "AI & Search",
    icon: "Search",
    description: "Web search engine",
  },
  {
    id: "chatgpt",
    name: "ChatGPT",
    aliases: ["chatgpt", "chat gpt", "openai", "open ai"],
    url: "https://chatgpt.com",
    category: "AI & Search",
    icon: "Bot",
    description: "OpenAI conversational assistant",
  },
  {
    id: "gemini",
    name: "Gemini",
    aliases: ["gemini", "google gemini", "bard"],
    url: "https://gemini.google.com",
    category: "AI & Search",
    icon: "Sparkles",
    description: "Google conversational AI",
  },
  {
    id: "claude",
    name: "Claude",
    aliases: ["claude", "anthropic", "claude ai"],
    url: "https://claude.ai",
    category: "AI & Search",
    icon: "Brain",
    description: "Anthropic AI assistant",
  },
  {
    id: "perplexity",
    name: "Perplexity",
    aliases: ["perplexity", "perplexity ai"],
    url: "https://www.perplexity.ai",
    category: "AI & Search",
    icon: "Compass",
    description: "AI-powered answer engine",
  },
  {
    id: "deepseek",
    name: "DeepSeek",
    aliases: ["deepseek", "deep seek", "deepseek ai"],
    url: "https://chat.deepseek.com",
    category: "AI & Search",
    icon: "Cpu",
    description: "DeepSeek reasoning assistant",
  },
  {
    id: "bing",
    name: "Bing",
    aliases: ["bing", "bing search", "copilot", "microsoft copilot"],
    url: "https://www.bing.com",
    category: "AI & Search",
    icon: "Search",
    description: "Microsoft search & AI",
  },

  // --- Media & Entertainment ---
  {
    id: "youtube",
    name: "YouTube",
    aliases: ["youtube", "you tube", "yt"],
    url: "https://www.youtube.com",
    category: "Media",
    icon: "Youtube",
    description: "Video sharing platform",
  },
  {
    id: "spotify",
    name: "Spotify",
    aliases: ["spotify", "music", "spotify music"],
    url: "https://open.spotify.com",
    category: "Media",
    icon: "Music",
    description: "Music & podcast streaming",
  },
  {
    id: "netflix",
    name: "Netflix",
    aliases: ["netflix", "movies", "shows"],
    url: "https://www.netflix.com",
    category: "Media",
    icon: "Film",
    description: "Movies and television streaming",
  },
  {
    id: "twitch",
    name: "Twitch",
    aliases: ["twitch", "twitch tv"],
    url: "https://www.twitch.tv",
    category: "Media",
    icon: "Tv",
    description: "Live streaming platform",
  },
  {
    id: "soundcloud",
    name: "SoundCloud",
    aliases: ["soundcloud", "sound cloud"],
    url: "https://soundcloud.com",
    category: "Media",
    icon: "Radio",
    description: "Music & audio discovery",
  },
  {
    id: "primevideo",
    name: "Prime Video",
    aliases: ["prime video", "amazon prime video", "amazon prime"],
    url: "https://www.primevideo.com",
    category: "Media",
    icon: "Video",
    description: "Amazon video streaming",
  },
  {
    id: "disneyplus",
    name: "Disney+",
    aliases: ["disney plus", "disney+", "disney"],
    url: "https://www.disneyplus.com",
    category: "Media",
    icon: "Clapperboard",
    description: "Disney streaming service",
  },
  {
    id: "applemusic",
    name: "Apple Music",
    aliases: ["apple music", "itunes"],
    url: "https://music.apple.com",
    category: "Media",
    icon: "Headphones",
    description: "Apple music streaming",
  },
  {
    id: "crunchyroll",
    name: "Crunchyroll",
    aliases: ["crunchyroll", "anime"],
    url: "https://www.crunchyroll.com",
    category: "Media",
    icon: "Flame",
    description: "Anime streaming service",
  },
  {
    id: "steam",
    name: "Steam",
    aliases: ["steam", "steam store", "games"],
    url: "https://store.steampowered.com",
    category: "Media",
    icon: "Gamepad2",
    description: "Gaming store & community",
  },

  // --- Social & Communication ---
  {
    id: "whatsapp",
    name: "WhatsApp",
    aliases: ["whatsapp", "whats app", "wa"],
    url: "https://web.whatsapp.com",
    category: "Social",
    icon: "MessageSquare",
    description: "Instant messaging & calls",
  },
  {
    id: "telegram",
    name: "Telegram",
    aliases: ["telegram", "tg"],
    url: "https://web.telegram.org",
    category: "Social",
    icon: "Send",
    description: "Cloud-based messaging app",
  },
  {
    id: "instagram",
    name: "Instagram",
    aliases: ["instagram", "insta", "ig"],
    url: "https://www.instagram.com",
    category: "Social",
    icon: "Camera",
    description: "Photo & video social network",
  },
  {
    id: "twitter",
    name: "X (Twitter)",
    aliases: ["twitter", "x", "x.com", "tweets"],
    url: "https://x.com",
    category: "Social",
    icon: "Share2",
    description: "Real-time microblogging & news",
  },
  {
    id: "reddit",
    name: "Reddit",
    aliases: ["reddit"],
    url: "https://www.reddit.com",
    category: "Social",
    icon: "MessageCircle",
    description: "Discussions, forums & communities",
  },
  {
    id: "discord",
    name: "Discord",
    aliases: ["discord"],
    url: "https://discord.com/app",
    category: "Social",
    icon: "Headphones",
    description: "Voice, video & text community chat",
  },
  {
    id: "linkedin",
    name: "LinkedIn",
    aliases: ["linkedin", "linked in"],
    url: "https://www.linkedin.com",
    category: "Social",
    icon: "Briefcase",
    description: "Professional networking platform",
  },
  {
    id: "facebook",
    name: "Facebook",
    aliases: ["facebook", "fb"],
    url: "https://www.facebook.com",
    category: "Social",
    icon: "Users",
    description: "Social media network",
  },
  {
    id: "tiktok",
    name: "TikTok",
    aliases: ["tiktok", "tik tok"],
    url: "https://www.tiktok.com",
    category: "Social",
    icon: "Video",
    description: "Short-form video network",
  },
  {
    id: "pinterest",
    name: "Pinterest",
    aliases: ["pinterest"],
    url: "https://www.pinterest.com",
    category: "Social",
    icon: "Pin",
    description: "Visual discovery & inspiration",
  },
  {
    id: "slack",
    name: "Slack",
    aliases: ["slack"],
    url: "https://app.slack.com",
    category: "Social",
    icon: "Hash",
    description: "Team communication & workspaces",
  },
  {
    id: "zoom",
    name: "Zoom",
    aliases: ["zoom", "zoom meeting"],
    url: "https://zoom.us/join",
    category: "Social",
    icon: "Video",
    description: "Video meetings and conferencing",
  },

  // --- Productivity & Work ---
  {
    id: "gmail",
    name: "Mail / Gmail",
    aliases: ["gmail", "email", "mail", "google mail"],
    url: "https://mail.google.com",
    category: "Productivity",
    icon: "Mail",
    description: "Webmail service",
  },
  {
    id: "maps",
    name: "Google Maps",
    aliases: ["maps", "google maps", "directions", "navigation"],
    url: "https://maps.google.com",
    category: "Productivity",
    icon: "MapPin",
    description: "Navigation and mapping service",
  },
  {
    id: "calendar",
    name: "Google Calendar",
    aliases: ["calendar", "google calendar", "schedule"],
    url: "https://calendar.google.com",
    category: "Productivity",
    icon: "Calendar",
    description: "Calendar & event organizer",
  },
  {
    id: "drive",
    name: "Google Drive",
    aliases: ["drive", "google drive"],
    url: "https://drive.google.com",
    category: "Productivity",
    icon: "HardDrive",
    description: "Cloud file storage & syncing",
  },
  {
    id: "docs",
    name: "Google Docs",
    aliases: ["docs", "google docs", "word processor"],
    url: "https://docs.google.com",
    category: "Productivity",
    icon: "FileText",
    description: "Online word documents",
  },
  {
    id: "sheets",
    name: "Google Sheets",
    aliases: ["sheets", "google sheets", "spreadsheets"],
    url: "https://sheets.google.com",
    category: "Productivity",
    icon: "Table",
    description: "Collaborative spreadsheets",
  },
  {
    id: "notion",
    name: "Notion",
    aliases: ["notion", "notion app"],
    url: "https://www.notion.so",
    category: "Productivity",
    icon: "BookOpen",
    description: "Notes, docs & workspace",
  },
  {
    id: "figma",
    name: "Figma",
    aliases: ["figma", "figma design"],
    url: "https://www.figma.com",
    category: "Productivity",
    icon: "PenTool",
    description: "Interface & vector design tool",
  },
  {
    id: "canva",
    name: "Canva",
    aliases: ["canva"],
    url: "https://www.canva.com",
    category: "Productivity",
    icon: "Palette",
    description: "Visual design & graphics platform",
  },
  {
    id: "trello",
    name: "Trello",
    aliases: ["trello", "kanban"],
    url: "https://trello.com",
    category: "Productivity",
    icon: "Columns",
    description: "Kanban board & task manager",
  },
  {
    id: "asana",
    name: "Asana",
    aliases: ["asana"],
    url: "https://app.asana.com",
    category: "Productivity",
    icon: "CheckSquare",
    description: "Team project management",
  },
  {
    id: "linear",
    name: "Linear",
    aliases: ["linear", "linear app"],
    url: "https://linear.app",
    category: "Productivity",
    icon: "CheckCircle",
    description: "Issue tracking for software teams",
  },
  {
    id: "miro",
    name: "Miro",
    aliases: ["miro", "whiteboard"],
    url: "https://miro.com",
    category: "Productivity",
    icon: "Layers",
    description: "Collaborative online whiteboard",
  },

  // --- Developer Tools ---
  {
    id: "github",
    name: "GitHub",
    aliases: ["github", "git hub", "git"],
    url: "https://github.com",
    category: "Developer",
    icon: "Github",
    description: "Code hosting & developer platform",
  },
  {
    id: "gitlab",
    name: "GitLab",
    aliases: ["gitlab", "git lab"],
    url: "https://gitlab.com",
    category: "Developer",
    icon: "GitBranch",
    description: "DevOps lifecycle tool",
  },
  {
    id: "stackoverflow",
    name: "Stack Overflow",
    aliases: ["stackoverflow", "stack overflow"],
    url: "https://stackoverflow.com",
    category: "Developer",
    icon: "HelpCircle",
    description: "Q&A community for programmers",
  },
  {
    id: "codepen",
    name: "CodePen",
    aliases: ["codepen", "code pen"],
    url: "https://codepen.io",
    category: "Developer",
    icon: "Code",
    description: "Online code editor and playground",
  },
  {
    id: "replit",
    name: "Replit",
    aliases: ["replit", "repl it"],
    url: "https://replit.com",
    category: "Developer",
    icon: "Terminal",
    description: "Collaborative browser IDE",
  },
  {
    id: "vercel",
    name: "Vercel",
    aliases: ["vercel"],
    url: "https://vercel.com",
    category: "Developer",
    icon: "Triangle",
    description: "Frontend cloud deployment platform",
  },
  {
    id: "supabase",
    name: "Supabase",
    aliases: ["supabase"],
    url: "https://supabase.com",
    category: "Developer",
    icon: "Database",
    description: "Open source Firebase alternative",
  },
  {
    id: "cloudflare",
    name: "Cloudflare",
    aliases: ["cloudflare"],
    url: "https://dash.cloudflare.com",
    category: "Developer",
    icon: "Cloud",
    description: "Web security and CDN dashboard",
  },

  // --- Shopping & Travel ---
  {
    id: "amazon",
    name: "Amazon",
    aliases: ["amazon", "shopping"],
    url: "https://www.amazon.com",
    category: "Shopping",
    icon: "ShoppingBag",
    description: "Online marketplace & shopping",
  },
  {
    id: "ebay",
    name: "eBay",
    aliases: ["ebay", "e bay"],
    url: "https://www.ebay.com",
    category: "Shopping",
    icon: "Tag",
    description: "Auctions & shopping marketplace",
  },
  {
    id: "uber",
    name: "Uber",
    aliases: ["uber", "ride"],
    url: "https://m.uber.com",
    category: "Shopping",
    icon: "Car",
    description: "Rideshare and transport",
  },
  {
    id: "airbnb",
    name: "Airbnb",
    aliases: ["airbnb", "air bnb"],
    url: "https://www.airbnb.com",
    category: "Shopping",
    icon: "Home",
    description: "Vacation stays & homes",
  },
  {
    id: "doordash",
    name: "DoorDash",
    aliases: ["doordash", "door dash", "food delivery"],
    url: "https://www.doordash.com",
    category: "Shopping",
    icon: "Utensils",
    description: "Restaurant food delivery",
  },

  // --- Education & Reference ---
  {
    id: "wikipedia",
    name: "Wikipedia",
    aliases: ["wikipedia", "wiki"],
    url: "https://www.wikipedia.org",
    category: "Education",
    icon: "Globe",
    description: "The free encyclopedia",
  },
  {
    id: "duolingo",
    name: "Duolingo",
    aliases: ["duolingo", "duo"],
    url: "https://www.duolingo.com",
    category: "Education",
    icon: "GraduationCap",
    description: "Language learning app",
  },
  {
    id: "coursera",
    name: "Coursera",
    aliases: ["coursera"],
    url: "https://www.coursera.org",
    category: "Education",
    icon: "BookMarked",
    description: "Online courses and degrees",
  },
  {
    id: "medium",
    name: "Medium",
    aliases: ["medium", "articles"],
    url: "https://medium.com",
    category: "Education",
    icon: "Bookmark",
    description: "Blogging & story publication",
  },

  // --- Utilities & Information ---
  {
    id: "weather",
    name: "Weather",
    aliases: ["weather", "forecast", "current weather"],
    url: "https://weather.com",
    category: "Utilities",
    icon: "CloudSun",
    description: "Live weather forecasts",
  },
  {
    id: "translate",
    name: "Google Translate",
    aliases: ["translate", "google translate", "translator"],
    url: "https://translate.google.com",
    category: "Utilities",
    icon: "Languages",
    description: "Language translation service",
  },
  {
    id: "speedtest",
    name: "Speedtest",
    aliases: ["speedtest", "speed test", "internet speed"],
    url: "https://www.speedtest.net",
    category: "Utilities",
    icon: "Gauge",
    description: "Internet connection speed test",
  },
  {
    id: "calculator",
    name: "Calculator",
    aliases: ["calculator", "calc", "math calculator"],
    url: "https://www.google.com/search?q=calculator",
    category: "Utilities",
    icon: "Calculator",
    description: "Scientific and basic calculator",
  },
  {
    id: "tradingview",
    name: "TradingView",
    aliases: ["tradingview", "trading view", "stocks", "crypto charts"],
    url: "https://www.tradingview.com",
    category: "Utilities",
    icon: "TrendingUp",
    description: "Financial markets and charts",
  },
];

/**
 * Normalizes input speech string by removing common trigger words.
 */
export function extractTargetAppName(input: string): string {
  let cleaned = input.toLowerCase().trim();

  // Strip punctuation
  cleaned = cleaned.replace(/[.,/#!$%^&*;:{}=\-_`~()?]/g, "");

  // Strip prefixes like "open", "launch", "start", "go to", "can you open", "please open"
  cleaned = cleaned
    .replace(/^(can you |could you |please )+/g, "")
    .replace(/^(open app |open the app |open the |open |launch the app |launch |start |go to the |go to )/g, "")
    .trim();

  // Strip trailing "app" or "website"
  cleaned = cleaned.replace(/\s+(app|application|website|web app|tab)$/g, "").trim();

  return cleaned;
}

export type ResolvedApp = {
  id: string;
  name: string;
  url: string;
  category: string;
  isCustom?: boolean;
};

/**
 * Matches spoken user text to a known registered app or creates a smart web URL.
 */
export function resolveAppFromSpeech(speech: string): ResolvedApp | null {
  const target = extractTargetAppName(speech);
  if (!target) return null;

  // 1. Direct or alias match in APP_REGISTRY
  const directMatch = APP_REGISTRY.find(
    (app) =>
      app.name.toLowerCase() === target ||
      app.id.toLowerCase() === target ||
      app.aliases.some((alias) => alias.toLowerCase() === target)
  );

  if (directMatch) {
    return {
      id: directMatch.id,
      name: directMatch.name,
      url: directMatch.url,
      category: directMatch.category,
    };
  }

  // 2. Partial containment match (e.g., target="spotify web", or app.alias inside target)
  const partialMatch = APP_REGISTRY.find(
    (app) =>
      target.startsWith(app.name.toLowerCase()) ||
      app.aliases.some((alias) => target === alias || target.startsWith(alias + " "))
  );

  if (partialMatch) {
    return {
      id: partialMatch.id,
      name: partialMatch.name,
      url: partialMatch.url,
      category: partialMatch.category,
    };
  }

  // 3. Spoken domain detection (e.g., "openai.com", "cnn.com", "bbc.co.uk")
  const domainMatch = target.match(/^([a-z0-9\-]+)\.(com|org|net|io|ai|co|app|dev|me|tv|gov)$/i);
  if (domainMatch) {
    const domain = domainMatch[0];
    const name = domainMatch[1].charAt(0).toUpperCase() + domainMatch[1].slice(1);
    return {
      id: domain.replace(/\./g, "-"),
      name: name,
      url: `https://${domain}`,
      category: "Utilities",
      isCustom: true,
    };
  }

  // 4. If user explicitly said "open [something]" or it looks like an application name (1-3 words)
  const words = target.split(/\s+/).filter(Boolean);
  if (words.length >= 1 && words.length <= 4) {
    const capitalizedName = words.map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");
    const slug = words.join("").toLowerCase();

    // Check if the original speech had an explicit open trigger
    const lowerOriginal = speech.toLowerCase();
    const isExplicitOpen =
      lowerOriginal.startsWith("open ") ||
      lowerOriginal.startsWith("launch ") ||
      lowerOriginal.startsWith("start ") ||
      lowerOriginal.startsWith("go to ");

    if (isExplicitOpen) {
      // Create high-probability direct web link or google search fallback
      return {
        id: slug,
        name: capitalizedName,
        url: `https://www.${slug}.com`,
        category: "Productivity",
        isCustom: true,
      };
    }
  }

  return null;
}
