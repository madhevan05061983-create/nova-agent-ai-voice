import { useCallback, useEffect, useState } from "react";
import { AuthActions } from "./components/auth-actions.tsx";
import { NovaConsole } from "./components/nova-console.tsx";
import { Sparkles, Mic, Layers, CheckCircle2, ArrowRight } from "lucide-react";

type UserSession = {
  name: string;
  email?: string;
  image?: string | null;
  provider?: string;
};

const BACKGROUND_VIDEO_URL =
  "https://res.cloudinary.com/lirx7iwb/video/upload/v1792684712/a_edit_1.mp4";

export default function App() {
  const [session, setSession] = useState<UserSession | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchSession = useCallback(async () => {
    try {
      const token = localStorage.getItem("nova_session_id");
      const headers: Record<string, string> = {};
      if (token) {
        headers["Authorization"] = `Bearer ${token}`;
      }
      const res = await fetch("/api/auth/session", { headers });
      if (res.ok) {
        const data = await res.json();
        setSession(data.user || null);
      }
    } catch {
      // ignore
    }
  }, []);

  useEffect(() => {
    fetchSession().finally(() => {
      setLoading(false);
    });
  }, [fetchSession]);

  const handleSignOut = useCallback(() => {
    try {
      localStorage.removeItem("nova_session_id");
      localStorage.removeItem("nova_auth_success");
    } catch {
      // ignore
    }
    setSession(null);
  }, []);

  const handleInstantLaunch = async () => {
    try {
      const res = await fetch("/api/auth/demo-signin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: "Operator" }),
      });
      const data = await res.json();
      if (data.ok && data.sessionId) {
        try {
          localStorage.setItem("nova_session_id", data.sessionId);
        } catch {
          // ignore
        }
        await fetchSession();
      }
    } catch {
      // ignore
    }
  };

  const displayName = session?.name || "Operator";

  if (loading) {
    return (
      <div className="relative flex min-h-screen items-center justify-center bg-slate-950 text-cyan-400">
        <div className="flex flex-col items-center gap-3">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-cyan-400 border-t-transparent" />
          <p className="text-sm font-medium tracking-wide text-slate-300">
            Initializing Nova Voice Agent…
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="relative min-h-screen w-full overflow-x-hidden text-white">
      {/* Dynamic Looping Video Background */}
      <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
        <video
          autoPlay
          loop
          muted
          playsInline
          className="h-full w-full object-cover"
          src={BACKGROUND_VIDEO_URL}
        />
        {/* Sleek contrast overlay to ensure maximum legibility and futuristic ambience */}
        <div className="absolute inset-0 bg-slate-950/70 backdrop-blur-[2px]" />
      </div>

      <main className="relative z-10 px-4 py-5 sm:px-6 lg:px-8">
        <div className="mx-auto flex w-full max-w-7xl flex-col gap-5">
          {/* Top Navigation Header */}
          <header className="rounded-[2rem] border border-white/10 bg-slate-950/60 px-6 py-4 shadow-[0_15px_60px_rgba(0,0,0,0.4)] backdrop-blur-xl">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-cyan-400/20 text-cyan-300 border border-cyan-400/30 shadow-[0_0_20px_rgba(34,211,238,0.2)]">
                  <Mic className="h-5 w-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold uppercase tracking-[0.24em] text-cyan-300">
                      Nova Voice Agent
                    </span>
                    <span className="rounded-full bg-cyan-400/15 border border-cyan-400/25 px-2 py-0.5 text-[10px] font-semibold text-cyan-300">
                      v2.5 Next-Gen
                    </span>
                  </div>
                  <h1 className="text-lg sm:text-xl font-bold tracking-tight text-white">
                    Intelligent Voice & App Launcher
                  </h1>
                </div>
              </div>

              <div className="flex items-center gap-3">
                {session && (
                  <div className="rounded-full border border-white/10 bg-white/5 px-4 py-1.5 text-xs font-medium text-slate-200 flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
                    <span>
                      Operator: <strong className="text-white font-semibold">{displayName}</strong>
                    </span>
                  </div>
                )}
                <AuthActions
                  signedIn={Boolean(session)}
                  onSignInSuccess={fetchSession}
                  onSignOut={handleSignOut}
                />
              </div>
            </div>
          </header>

          {/* Main Content Area */}
          {session ? (
            <NovaConsole displayName={displayName} onSignOut={handleSignOut} />
          ) : (
            <section className="flex flex-col items-center justify-center rounded-[2.5rem] border border-white/10 bg-slate-950/70 px-6 py-14 sm:py-20 text-center shadow-[0_24px_80px_rgba(0,0,0,0.5)] backdrop-blur-2xl">
              {/* Glowing Interactive Voice Orb */}
              <div className="relative mb-8 flex items-center justify-center">
                <div className="absolute h-40 w-40 rounded-full bg-cyan-400/25 blur-3xl animate-pulse" />
                <button
                  type="button"
                  onClick={handleInstantLaunch}
                  className="relative flex h-28 w-28 items-center justify-center rounded-full border border-cyan-400/50 bg-slate-900/90 shadow-[0_0_50px_rgba(34,211,238,0.4)] transition hover:scale-105 active:scale-95 cursor-pointer"
                  title="Click to activate voice console immediately"
                >
                  <Mic className="h-12 w-12 text-cyan-300" />
                </button>
              </div>

              <h2 className="text-3xl font-extrabold tracking-tight text-white sm:text-5xl max-w-2xl">
                Activate Nova Voice Assistant
              </h2>
              <p className="mt-4 max-w-xl text-base text-slate-300 leading-relaxed">
                Speak any application name to open it immediately, manage tabs, take voice notes, set timers, and automate tasks with seamless real-time voice intelligence.
              </p>

              {/* Seamless Action Buttons */}
              <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
                <button
                  type="button"
                  onClick={handleInstantLaunch}
                  className="inline-flex items-center gap-2 rounded-full bg-cyan-400 px-8 py-3.5 text-sm font-bold text-slate-950 hover:bg-cyan-300 active:scale-95 transition shadow-lg shadow-cyan-400/30 cursor-pointer"
                >
                  <span>Launch Voice Console</span>
                  <ArrowRight className="h-4 w-4" />
                </button>

                <AuthActions
                  signedIn={false}
                  onSignInSuccess={fetchSession}
                  onSignOut={handleSignOut}
                />
              </div>

              {/* Feature Highlights Grid */}
              <div className="mt-12 grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-4xl w-full text-left">
                <div className="rounded-2xl border border-white/10 bg-white/5 p-4 backdrop-blur-sm">
                  <div className="flex items-center gap-2 text-cyan-300 font-bold text-sm mb-1.5">
                    <Sparkles className="h-4 w-4" />
                    <span>Speak Any App Name</span>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Say "Open Spotify", "Open WhatsApp", "Open Netflix", or any of 120+ web apps to launch them in new tabs.
                  </p>
                </div>

                <div className="rounded-2xl border border-white/10 bg-white/5 p-4 backdrop-blur-sm">
                  <div className="flex items-center gap-2 text-cyan-300 font-bold text-sm mb-1.5">
                    <Layers className="h-4 w-4" />
                    <span>Smart Tab Automation</span>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Say "Close tabs" or "Close Spotify" to clean up and manage active browser tabs automatically on voice command.
                  </p>
                </div>

                <div className="rounded-2xl border border-white/10 bg-white/5 p-4 backdrop-blur-sm">
                  <div className="flex items-center gap-2 text-cyan-300 font-bold text-sm mb-1.5">
                    <CheckCircle2 className="h-4 w-4" />
                    <span>Voice Notes & Checklist</span>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Say "Take a note...", "Add task...", or "Set timer 5 min" to organize your productivity seamlessly hands-free.
                  </p>
                </div>
              </div>
            </section>
          )}
        </div>
      </main>
    </div>
  );
}
