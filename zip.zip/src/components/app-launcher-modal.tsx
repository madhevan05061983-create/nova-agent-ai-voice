import { useState, useMemo } from "react";
import { Search, X, ExternalLink, Sparkles, Grid } from "lucide-react";
import { APP_REGISTRY, AppDefinition } from "../lib/apps.ts";

type AppLauncherModalProps = {
  isOpen: boolean;
  onClose: () => void;
  onOpenApp: (app: AppDefinition) => void;
};

const CATEGORIES = [
  "All",
  "AI & Search",
  "Media",
  "Social",
  "Productivity",
  "Developer",
  "Shopping",
  "Utilities",
  "Education",
] as const;

export function AppLauncherModal({ isOpen, onClose, onOpenApp }: AppLauncherModalProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("All");

  const filteredApps = useMemo(() => {
    return APP_REGISTRY.filter((app) => {
      const matchesSearch =
        searchTerm.trim() === "" ||
        app.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        app.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        app.aliases.some((a) => a.toLowerCase().includes(searchTerm.toLowerCase()));

      const matchesCategory =
        selectedCategory === "All" || app.category === selectedCategory;

      return matchesSearch && matchesCategory;
    });
  }, [searchTerm, selectedCategory]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative flex flex-col w-full max-w-4xl max-h-[85vh] rounded-[2.5rem] border border-cyan-400/30 bg-slate-950/90 shadow-[0_25px_80px_rgba(34,211,238,0.25)] text-white overflow-hidden">
        {/* Header Bar */}
        <div className="flex items-center justify-between border-b border-white/10 px-6 py-5">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-cyan-400/20 text-cyan-300 border border-cyan-400/30">
              <Grid className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-[0.22em] text-cyan-300">Application Hub</span>
                <span className="rounded-full bg-cyan-400/20 px-2 py-0.5 text-[10px] font-semibold text-cyan-300 border border-cyan-400/30">
                  {APP_REGISTRY.length}+ Apps
                </span>
              </div>
              <h2 className="text-lg sm:text-xl font-bold text-white">Speak Any App Name to Launch</h2>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="rounded-full p-2 text-slate-400 hover:text-white hover:bg-white/10 transition cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Search & Category Filter Bar */}
        <div className="border-b border-white/10 px-6 py-4 space-y-3 bg-slate-900/50">
          <div className="relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by app name or keyword (e.g. Spotify, YouTube, WhatsApp, Figma)..."
              className="w-full rounded-2xl border border-white/10 bg-slate-950/80 pl-10 pr-4 py-2.5 text-xs sm:text-sm text-white placeholder:text-slate-500 focus:border-cyan-400 outline-none"
            />
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedCategory(cat)}
                className={`shrink-0 rounded-full px-3 py-1 text-xs font-medium transition cursor-pointer ${
                  selectedCategory === cat
                    ? "bg-cyan-400 text-slate-950 font-bold shadow-sm"
                    : "border border-white/10 bg-white/5 text-slate-300 hover:bg-white/10"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Apps Grid */}
        <div className="flex-1 overflow-y-auto p-6 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {filteredApps.map((app) => (
            <div
              key={app.id}
              onClick={() => {
                onOpenApp(app);
                onClose();
              }}
              className="group flex flex-col justify-between rounded-2xl border border-white/10 bg-white/5 p-4 hover:border-cyan-400/50 hover:bg-cyan-400/10 transition cursor-pointer shadow-sm hover:shadow-cyan-400/10"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-cyan-300/80">
                    {app.category}
                  </span>
                  <ExternalLink className="h-3.5 w-3.5 text-slate-500 group-hover:text-cyan-300 transition" />
                </div>
                <h4 className="text-sm font-bold text-white group-hover:text-cyan-200 transition">
                  {app.name}
                </h4>
                <p className="text-xs text-slate-400 mt-1 line-clamp-1">{app.description}</p>
              </div>

              <div className="mt-3 flex items-center justify-between border-t border-white/5 pt-2">
                <span className="text-[10px] text-cyan-300/80 font-mono">
                  Speak "Open {app.name}"
                </span>
                <span className="rounded-lg bg-cyan-400/20 px-2 py-0.5 text-[10px] font-semibold text-cyan-300 group-hover:bg-cyan-400 group-hover:text-slate-950 transition">
                  Launch
                </span>
              </div>
            </div>
          ))}

          {filteredApps.length === 0 && (
            <div className="col-span-full py-12 text-center text-slate-400">
              <Sparkles className="h-8 w-8 text-slate-600 mx-auto mb-2" />
              <p className="text-sm">No apps match "{searchTerm}".</p>
              <p className="text-xs text-slate-500 mt-1">
                You can still say "Open {searchTerm}" to launch it directly!
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
