import { useState, useEffect, useRef } from "react";
import {
  CheckSquare,
  Square,
  Trash2,
  Plus,
  StickyNote,
  Timer,
  Play,
  Pause,
  RotateCcw,
  Volume2,
  Copy,
  Check,
  ExternalLink,
  Layers,
} from "lucide-react";

export type TaskItem = {
  id: string;
  text: string;
  completed: boolean;
  createdAt: number;
};

export type NoteItem = {
  id: string;
  content: string;
  createdAt: number;
};

export type TrackedTab = {
  id: string;
  url: string;
  label: string;
  openedAt: number;
};

type ProductivityPanelProps = {
  tasks: TaskItem[];
  notes: NoteItem[];
  activeTabs: TrackedTab[];
  onAddTask: (text: string) => void;
  onToggleTask: (id: string) => void;
  onDeleteTask: (id: string) => void;
  onClearTasks: () => void;
  onAddNote: (content: string) => void;
  onDeleteNote: (id: string) => void;
  onClearNotes: () => void;
  onCloseTab: (tabId: string) => void;
  onCloseAllTabs: () => void;
  onSpeak: (text: string) => void;
  activeTimerDuration?: number | null;
  onTimerComplete?: () => void;
};

export function ProductivityPanel({
  tasks,
  notes,
  activeTabs,
  onAddTask,
  onToggleTask,
  onDeleteTask,
  onClearTasks,
  onAddNote,
  onDeleteNote,
  onClearNotes,
  onCloseTab,
  onCloseAllTabs,
  onSpeak,
  activeTimerDuration,
  onTimerComplete,
}: ProductivityPanelProps) {
  const [activeSubTab, setActiveSubTab] = useState<"tasks" | "notes" | "timer" | "tabs">("tasks");
  const [newTaskInput, setNewTaskInput] = useState("");
  const [newNoteInput, setNewNoteInput] = useState("");
  const [copiedNoteId, setCopiedNoteId] = useState<string | null>(null);

  // Timer states
  const [timerSecondsLeft, setTimerSecondsLeft] = useState<number>(0);
  const [timerTotal, setTimerTotal] = useState<number>(0);
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const timerIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Sync external voice timer command
  useEffect(() => {
    if (activeTimerDuration && activeTimerDuration > 0) {
      setTimerTotal(activeTimerDuration);
      setTimerSecondsLeft(activeTimerDuration);
      setIsTimerRunning(true);
      setActiveSubTab("timer");
    }
  }, [activeTimerDuration]);

  // Timer tick
  useEffect(() => {
    if (isTimerRunning && timerSecondsLeft > 0) {
      timerIntervalRef.current = setInterval(() => {
        setTimerSecondsLeft((prev) => {
          if (prev <= 1) {
            clearInterval(timerIntervalRef.current!);
            setIsTimerRunning(false);
            if (onTimerComplete) onTimerComplete();
            onSpeak("Timer complete! Your time is up.");
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    }
    return () => {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    };
  }, [isTimerRunning, timerSecondsLeft, onSpeak, onTimerComplete]);

  const handleStartPresetTimer = (seconds: number) => {
    setTimerTotal(seconds);
    setTimerSecondsLeft(seconds);
    setIsTimerRunning(true);
  };

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskInput.trim()) return;
    onAddTask(newTaskInput.trim());
    setNewTaskInput("");
  };

  const handleCreateNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNoteInput.trim()) return;
    onAddNote(newNoteInput.trim());
    setNewNoteInput("");
  };

  const handleCopyNote = (id: string, content: string) => {
    try {
      navigator.clipboard.writeText(content);
      setCopiedNoteId(id);
      setTimeout(() => setCopiedNoteId(null), 1600);
    } catch {
      // ignore
    }
  };

  const formatTimerTime = (totalSec: number) => {
    const mins = Math.floor(totalSec / 60);
    const secs = totalSec % 60;
    return `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
  };

  return (
    <div className="flex flex-col h-full rounded-[2rem] border border-white/10 bg-slate-900/70 backdrop-blur-xl p-5 sm:p-6 shadow-[0_20px_60px_rgba(0,0,0,0.4)] text-white">
      {/* Subtab Navigation */}
      <div className="flex items-center justify-between border-b border-white/10 pb-4">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-[0.25em] text-cyan-300">Workspace</span>
          <h3 className="text-lg font-bold text-white">Productivity Center</h3>
        </div>

        <div className="flex items-center gap-1 rounded-xl bg-slate-950/80 p-1 border border-white/10">
          <button
            type="button"
            onClick={() => setActiveSubTab("tasks")}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
              activeSubTab === "tasks"
                ? "bg-cyan-400 text-slate-950 shadow-sm"
                : "text-slate-400 hover:text-white"
            }`}
          >
            <CheckSquare className="h-3.5 w-3.5" />
            <span>Tasks</span>
            {tasks.length > 0 && (
              <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${activeSubTab === "tasks" ? "bg-slate-950/20 text-slate-950 font-bold" : "bg-white/10 text-cyan-300"}`}>
                {tasks.filter((t) => !t.completed).length}
              </span>
            )}
          </button>

          <button
            type="button"
            onClick={() => setActiveSubTab("notes")}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
              activeSubTab === "notes"
                ? "bg-cyan-400 text-slate-950 shadow-sm"
                : "text-slate-400 hover:text-white"
            }`}
          >
            <StickyNote className="h-3.5 w-3.5" />
            <span>Notes</span>
            {notes.length > 0 && (
              <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${activeSubTab === "notes" ? "bg-slate-950/20 text-slate-950 font-bold" : "bg-white/10 text-cyan-300"}`}>
                {notes.length}
              </span>
            )}
          </button>

          <button
            type="button"
            onClick={() => setActiveSubTab("timer")}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
              activeSubTab === "timer"
                ? "bg-cyan-400 text-slate-950 shadow-sm"
                : "text-slate-400 hover:text-white"
            }`}
          >
            <Timer className="h-3.5 w-3.5" />
            <span>Timer</span>
            {isTimerRunning && (
              <span className="h-2 w-2 rounded-full bg-emerald-400 animate-ping" />
            )}
          </button>

          <button
            type="button"
            onClick={() => setActiveSubTab("tabs")}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
              activeSubTab === "tabs"
                ? "bg-cyan-400 text-slate-950 shadow-sm"
                : "text-slate-400 hover:text-white"
            }`}
          >
            <Layers className="h-3.5 w-3.5" />
            <span>Tabs</span>
            {activeTabs.length > 0 && (
              <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${activeSubTab === "tabs" ? "bg-slate-950/20 text-slate-950 font-bold" : "bg-white/10 text-cyan-300"}`}>
                {activeTabs.length}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Content Area */}
      <div className="mt-4 flex-1 flex flex-col min-h-[320px]">
        {/* TAB 1: TASKS */}
        {activeSubTab === "tasks" && (
          <div className="flex flex-col h-full space-y-4">
            <form onSubmit={handleCreateTask} className="flex gap-2">
              <input
                type="text"
                value={newTaskInput}
                onChange={(e) => setNewTaskInput(e.target.value)}
                placeholder="Add task or speak 'Add task review code'..."
                className="flex-1 rounded-xl border border-white/10 bg-slate-950/70 px-3.5 py-2 text-xs text-white placeholder:text-slate-500 focus:border-cyan-400 outline-none"
              />
              <button
                type="submit"
                disabled={!newTaskInput.trim()}
                className="flex items-center gap-1 rounded-xl bg-cyan-400 px-3 py-2 text-xs font-bold text-slate-950 hover:bg-cyan-300 disabled:opacity-40 transition cursor-pointer"
              >
                <Plus className="h-3.5 w-3.5" />
                <span>Add</span>
              </button>
            </form>

            <div className="flex items-center justify-between text-xs text-slate-400 px-1">
              <span>{tasks.filter((t) => t.completed).length} of {tasks.length} completed</span>
              {tasks.length > 0 && (
                <button
                  type="button"
                  onClick={onClearTasks}
                  className="text-slate-400 hover:text-rose-300 text-[11px] transition cursor-pointer"
                >
                  Clear All
                </button>
              )}
            </div>

            <div className="flex-1 space-y-2 overflow-y-auto max-h-[290px] pr-1">
              {tasks.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-10 text-center text-slate-400">
                  <CheckSquare className="h-8 w-8 text-slate-600 mb-2" />
                  <p className="text-xs">No active tasks yet.</p>
                  <p className="text-[11px] text-slate-500 mt-1">Speak: "Add task update presentation" or type above.</p>
                </div>
              ) : (
                tasks.map((task) => (
                  <div
                    key={task.id}
                    className={`flex items-center justify-between gap-2.5 rounded-xl border p-2.5 text-xs transition ${
                      task.completed
                        ? "border-white/5 bg-white/5 text-slate-400"
                        : "border-cyan-400/20 bg-slate-950/60 text-white"
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => onToggleTask(task.id)}
                      className="flex items-center gap-2.5 flex-1 text-left cursor-pointer"
                    >
                      {task.completed ? (
                        <CheckSquare className="h-4 w-4 text-emerald-400 shrink-0" />
                      ) : (
                        <Square className="h-4 w-4 text-slate-400 shrink-0 hover:text-cyan-400" />
                      )}
                      <span className={task.completed ? "line-through text-slate-500" : ""}>
                        {task.text}
                      </span>
                    </button>
                    <button
                      type="button"
                      onClick={() => onDeleteTask(task.id)}
                      className="text-slate-500 hover:text-rose-400 p-1 rounded transition cursor-pointer"
                      title="Delete task"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* TAB 2: NOTES */}
        {activeSubTab === "notes" && (
          <div className="flex flex-col h-full space-y-4">
            <form onSubmit={handleCreateNote} className="flex gap-2">
              <input
                type="text"
                value={newNoteInput}
                onChange={(e) => setNewNoteInput(e.target.value)}
                placeholder="Take note or speak 'Take note client meeting at 4'..."
                className="flex-1 rounded-xl border border-white/10 bg-slate-950/70 px-3.5 py-2 text-xs text-white placeholder:text-slate-500 focus:border-cyan-400 outline-none"
              />
              <button
                type="submit"
                disabled={!newNoteInput.trim()}
                className="flex items-center gap-1 rounded-xl bg-cyan-400 px-3 py-2 text-xs font-bold text-slate-950 hover:bg-cyan-300 disabled:opacity-40 transition cursor-pointer"
              >
                <Plus className="h-3.5 w-3.5" />
                <span>Save</span>
              </button>
            </form>

            <div className="flex items-center justify-between text-xs text-slate-400 px-1">
              <span>{notes.length} note{notes.length === 1 ? "" : "s"} saved</span>
              {notes.length > 0 && (
                <button
                  type="button"
                  onClick={onClearNotes}
                  className="text-slate-400 hover:text-rose-300 text-[11px] transition cursor-pointer"
                >
                  Clear Notes
                </button>
              )}
            </div>

            <div className="flex-1 space-y-2.5 overflow-y-auto max-h-[290px] pr-1">
              {notes.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-10 text-center text-slate-400">
                  <StickyNote className="h-8 w-8 text-slate-600 mb-2" />
                  <p className="text-xs">No voice notes saved.</p>
                  <p className="text-[11px] text-slate-500 mt-1">Speak: "Take a note check flight schedule" or save above.</p>
                </div>
              ) : (
                notes.map((note) => (
                  <div
                    key={note.id}
                    className="flex flex-col gap-2 rounded-xl border border-white/10 bg-slate-950/70 p-3 text-xs"
                  >
                    <p className="text-slate-200 leading-relaxed whitespace-pre-wrap">{note.content}</p>
                    <div className="flex items-center justify-between border-t border-white/5 pt-2 text-[10px] text-slate-500">
                      <span>{new Date(note.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => onSpeak(note.content)}
                          className="text-slate-400 hover:text-cyan-300 flex items-center gap-1 transition cursor-pointer"
                          title="Read note aloud"
                        >
                          <Volume2 className="h-3 w-3" />
                          <span>Speak</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleCopyNote(note.id, note.content)}
                          className="text-slate-400 hover:text-white flex items-center gap-1 transition cursor-pointer"
                        >
                          {copiedNoteId === note.id ? (
                            <>
                              <Check className="h-3 w-3 text-emerald-400" />
                              <span className="text-emerald-400">Copied</span>
                            </>
                          ) : (
                            <>
                              <Copy className="h-3 w-3" />
                              <span>Copy</span>
                            </>
                          )}
                        </button>
                        <button
                          type="button"
                          onClick={() => onDeleteNote(note.id)}
                          className="text-slate-500 hover:text-rose-400 p-0.5 transition cursor-pointer"
                          title="Delete note"
                        >
                          <Trash2 className="h-3 w-3" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* TAB 3: TIMER & STOPWATCH */}
        {activeSubTab === "timer" && (
          <div className="flex flex-col items-center justify-center flex-1 space-y-5 text-center">
            {/* Visual Circular / Digital Counter */}
            <div className="relative flex items-center justify-center">
              <div className="h-36 w-36 rounded-full border-4 border-cyan-400/20 flex flex-col items-center justify-center bg-slate-950/80 shadow-[0_0_40px_rgba(34,211,238,0.15)]">
                <span className="font-mono text-3xl font-extrabold text-cyan-300">
                  {formatTimerTime(timerSecondsLeft)}
                </span>
                <span className="text-[10px] text-slate-400 mt-1 uppercase tracking-wider">
                  {isTimerRunning ? "Counting Down" : timerSecondsLeft > 0 ? "Paused" : "Idle"}
                </span>
              </div>
            </div>

            {/* Timer Controls */}
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setIsTimerRunning(!isTimerRunning)}
                disabled={timerSecondsLeft === 0}
                className="flex items-center gap-1.5 rounded-full bg-cyan-400 px-5 py-2 text-xs font-bold text-slate-950 hover:bg-cyan-300 disabled:opacity-40 transition cursor-pointer"
              >
                {isTimerRunning ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
                <span>{isTimerRunning ? "Pause" : "Start"}</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setIsTimerRunning(false);
                  setTimerSecondsLeft(timerTotal);
                }}
                disabled={timerTotal === 0}
                className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-xs font-semibold text-slate-300 hover:bg-white/10 disabled:opacity-40 transition cursor-pointer"
              >
                <RotateCcw className="h-3.5 w-3.5" />
                <span>Reset</span>
              </button>
            </div>

            {/* Quick Presets */}
            <div className="space-y-1.5 pt-2">
              <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Quick Presets / Voice: "Timer 5 min"</p>
              <div className="flex flex-wrap justify-center gap-2">
                {[
                  { label: "1 min", sec: 60 },
                  { label: "5 min", sec: 300 },
                  { label: "15 min", sec: 900 },
                  { label: "25 min (Pomodoro)", sec: 1500 },
                ].map((preset) => (
                  <button
                    key={preset.sec}
                    type="button"
                    onClick={() => handleStartPresetTimer(preset.sec)}
                    className="rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-medium text-slate-300 hover:border-cyan-400/50 hover:text-cyan-300 transition cursor-pointer"
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: ACTIVE OPENED TABS */}
        {activeSubTab === "tabs" && (
          <div className="flex flex-col h-full space-y-3">
            <div className="flex items-center justify-between text-xs text-slate-400 px-1">
              <span>{activeTabs.length} tab{activeTabs.length === 1 ? "" : "s"} opened by voice</span>
              {activeTabs.length > 0 && (
                <button
                  type="button"
                  onClick={onCloseAllTabs}
                  className="rounded-lg bg-rose-500/20 border border-rose-500/30 px-2.5 py-1 text-[11px] font-semibold text-rose-300 hover:bg-rose-500/30 transition cursor-pointer"
                >
                  Close All Tabs
                </button>
              )}
            </div>

            <div className="flex-1 space-y-2 overflow-y-auto max-h-[290px] pr-1">
              {activeTabs.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-center text-slate-400">
                  <Layers className="h-8 w-8 text-slate-600 mb-2" />
                  <p className="text-xs">No active tabs opened yet.</p>
                  <p className="text-[11px] text-slate-500 mt-1">Speak any app name: "Open Spotify", "Open YouTube", "Open WhatsApp".</p>
                </div>
              ) : (
                activeTabs.map((tab) => (
                  <div
                    key={tab.id}
                    className="flex items-center justify-between gap-3 rounded-xl border border-white/10 bg-slate-950/70 p-3 text-xs"
                  >
                    <div className="min-w-0 flex-1">
                      <p className="font-semibold text-white truncate">{tab.label}</p>
                      <p className="text-[10px] text-slate-400 truncate mt-0.5">{tab.url}</p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <a
                        href={tab.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="rounded-lg bg-white/10 p-1.5 text-slate-300 hover:text-white transition"
                        title="Switch to tab"
                      >
                        <ExternalLink className="h-3.5 w-3.5" />
                      </a>
                      <button
                        type="button"
                        onClick={() => onCloseTab(tab.id)}
                        className="rounded-lg bg-rose-500/20 border border-rose-500/30 px-2 py-1 text-[11px] font-semibold text-rose-300 hover:bg-rose-500/30 transition cursor-pointer"
                      >
                        Close
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
