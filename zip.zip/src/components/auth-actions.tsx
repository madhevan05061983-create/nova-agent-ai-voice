import { useState, useEffect, useRef } from "react";

type AuthActionsProps = {
  signedIn: boolean;
  onSignInSuccess: () => void;
  onSignOut: () => void;
};

export function AuthActions({
  signedIn,
  onSignInSuccess,
  onSignOut,
}: AuthActionsProps) {
  const [pending, setPending] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const pollTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Clean up polling on unmount
  useEffect(() => {
    return () => {
      if (pollTimerRef.current) {
        clearInterval(pollTimerRef.current);
        pollTimerRef.current = null;
      }
    };
  }, []);

  // Multi-channel auth listener
  useEffect(() => {
    const handleAuthSuccess = (sessionId?: string) => {
      if (sessionId) {
        try {
          localStorage.setItem("nova_session_id", sessionId);
        } catch {
          // ignore
        }
      }
      if (pollTimerRef.current) {
        clearInterval(pollTimerRef.current);
        pollTimerRef.current = null;
      }
      setPending(false);
      setErrorMessage(null);
      onSignInSuccess();
    };

    const handleWindowMessage = (event: MessageEvent) => {
      if (event.data?.type === "OAUTH_AUTH_SUCCESS") {
        handleAuthSuccess(event.data.sessionId);
      } else if (event.data?.type === "OAUTH_AUTH_ERROR") {
        setPending(false);
        setErrorMessage(event.data.error || "Authentication was canceled.");
      }
    };
    window.addEventListener("message", handleWindowMessage);

    let bc: BroadcastChannel | null = null;
    try {
      bc = new BroadcastChannel("nova_auth");
      bc.onmessage = (event) => {
        if (event.data?.type === "OAUTH_AUTH_SUCCESS") {
          handleAuthSuccess(event.data.sessionId);
        }
      };
    } catch {
      // ignore
    }

    const handleStorage = (event: StorageEvent) => {
      if (event.key === "nova_auth_success" || event.key === "nova_session_id") {
        const storedToken = localStorage.getItem("nova_session_id") || undefined;
        handleAuthSuccess(storedToken);
      }
    };
    window.addEventListener("storage", handleStorage);

    return () => {
      window.removeEventListener("message", handleWindowMessage);
      window.removeEventListener("storage", handleStorage);
      if (bc) bc.close();
    };
  }, [onSignInSuccess]);

  // Seamless 1-Click Instant Access
  const handleSeamlessConnect = async () => {
    setPending(true);
    setErrorMessage(null);
    try {
      const res = await fetch("/api/auth/demo-signin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: "Operator" }),
      });
      const data = await res.json();
      if (data.ok && data.sessionId) {
        try {
          localStorage.setItem("nova_session_id", data.sessionId);
        } catch {
          // ignore
        }
        onSignInSuccess();
      } else {
        throw new Error("Could not initialize session.");
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Connection failed";
      setErrorMessage(msg);
    } finally {
      setPending(false);
    }
  };

  // Google OAuth popup
  const handleGoogleSignIn = () => {
    setPending(true);
    setErrorMessage(null);

    const width = 560;
    const height = 660;
    const left = window.screenX + (window.outerWidth - width) / 2;
    const top = window.screenY + (window.outerHeight - height) / 2;

    const authWindow = window.open(
      "about:blank",
      "google_oauth_popup",
      `width=${width},height=${height},left=${left},top=${top},status=no,menubar=no,toolbar=no`
    );

    fetch("/api/auth/url")
      .then(async (response) => {
        const data = await response.json();
        if (!response.ok || !data.url) {
          // If OAuth isn't configured, fall back gracefully to seamless 1-click connect!
          if (authWindow && !authWindow.closed) {
            authWindow.close();
          }
          await handleSeamlessConnect();
          return;
        }
        if (authWindow) {
          authWindow.location.href = data.url;
        } else {
          window.location.href = data.url;
        }
      })
      .catch(async () => {
        if (authWindow && !authWindow.closed) {
          authWindow.close();
        }
        // Seamless fallback
        await handleSeamlessConnect();
      });

    if (pollTimerRef.current) {
      clearInterval(pollTimerRef.current);
    }

    const checkSession = async () => {
      try {
        const token = localStorage.getItem("nova_session_id");
        const headers: Record<string, string> = {};
        if (token) {
          headers["Authorization"] = `Bearer ${token}`;
        }
        const res = await fetch("/api/auth/session", { headers });
        if (res.ok) {
          const s = await res.json();
          if (s.user) {
            if (pollTimerRef.current) {
              clearInterval(pollTimerRef.current);
              pollTimerRef.current = null;
            }
            if (authWindow && !authWindow.closed) {
              authWindow.close();
            }
            setPending(false);
            setErrorMessage(null);
            onSignInSuccess();
            return true;
          }
        }
      } catch {
        // ignore
      }
      return false;
    };

    pollTimerRef.current = setInterval(async () => {
      const loggedIn = await checkSession();
      if (loggedIn) return;

      if (authWindow?.closed) {
        if (pollTimerRef.current) {
          clearInterval(pollTimerRef.current);
          pollTimerRef.current = null;
        }
        setTimeout(async () => {
          const finished = await checkSession();
          if (!finished) {
            setPending(false);
          }
        }, 600);
      }
    }, 800);
  };

  const handleSignOutClick = async () => {
    setPending(true);
    try {
      const token = localStorage.getItem("nova_session_id");
      const headers: Record<string, string> = {};
      if (token) {
        headers["Authorization"] = `Bearer ${token}`;
      }
      await fetch("/api/auth/signout", { method: "POST", headers });
      try {
        localStorage.removeItem("nova_session_id");
        localStorage.removeItem("nova_auth_success");
      } catch {
        // ignore
      }
      onSignOut();
    } finally {
      setPending(false);
    }
  };

  if (signedIn) {
    return (
      <button
        type="button"
        onClick={handleSignOutClick}
        disabled={pending}
        className="inline-flex items-center justify-center rounded-xl border border-white/10 bg-white/5 px-3.5 py-1.5 text-xs font-semibold text-slate-300 hover:text-white hover:bg-white/10 hover:border-white/20 transition cursor-pointer disabled:opacity-50"
      >
        {pending ? "Signing out…" : "Sign out"}
      </button>
    );
  }

  return (
    <div className="flex flex-wrap items-center gap-2.5">
      <button
        type="button"
        onClick={handleSeamlessConnect}
        disabled={pending}
        className="inline-flex items-center justify-center rounded-full bg-cyan-400 px-6 py-2.5 text-xs font-bold text-slate-950 transition hover:bg-cyan-300 active:scale-95 disabled:opacity-60 shadow-lg shadow-cyan-400/20 cursor-pointer"
      >
        {pending ? "Connecting…" : "Launch Console"}
      </button>

      <button
        type="button"
        onClick={handleGoogleSignIn}
        disabled={pending}
        className="inline-flex items-center justify-center rounded-full border border-white/15 bg-white/5 px-4 py-2.5 text-xs font-semibold text-slate-200 transition hover:bg-white/10 hover:border-white/25 active:scale-95 disabled:opacity-60 cursor-pointer"
      >
        Sign in with Google
      </button>

      {errorMessage && (
        <span className="text-[11px] text-rose-300 bg-rose-500/10 border border-rose-500/20 rounded-lg px-2.5 py-1">
          {errorMessage}
        </span>
      )}
    </div>
  );
}
