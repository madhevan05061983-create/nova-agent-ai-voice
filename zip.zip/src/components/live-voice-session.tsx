import { useCallback, useEffect, useRef, useState } from "react";
import { Mic, MicOff, X, Send, Volume2, Sparkles, AlertCircle } from "lucide-react";

type LiveVoiceSessionProps = {
  displayName: string;
  onClose: () => void;
};

function downsampleTo16kHz(input: Float32Array, inputSampleRate: number): Int16Array {
  if (inputSampleRate === 16000) {
    const output = new Int16Array(input.length);
    for (let i = 0; i < input.length; i++) {
      const s = Math.max(-1, Math.min(1, input[i]));
      output[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
    }
    return output;
  }

  const ratio = inputSampleRate / 16000;
  const outputLength = Math.round(input.length / ratio);
  const output = new Int16Array(outputLength);
  for (let i = 0; i < outputLength; i++) {
    const srcIndex = Math.min(Math.round(i * ratio), input.length - 1);
    const s = Math.max(-1, Math.min(1, input[srcIndex]));
    output[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
  }
  return output;
}

function pcmToBase64(int16Array: Int16Array): string {
  let binary = "";
  const bytes = new Uint8Array(int16Array.buffer);
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

export function LiveVoiceSession({ displayName, onClose }: LiveVoiceSessionProps) {
  const [connected, setConnected] = useState(false);
  const [connecting, setConnecting] = useState(false);
  const [micActive, setMicActive] = useState(false);
  const [isAiSpeaking, setIsAiSpeaking] = useState(false);
  const [micMuted, setMicMuted] = useState(false);
  const [micVolume, setMicVolume] = useState(0);
  const [transcriptHistory, setTranscriptHistory] = useState<string[]>([]);
  const [currentAiTranscript, setCurrentAiTranscript] = useState("");
  const [status, setStatus] = useState("Connecting to voice stream...");
  const [micError, setMicError] = useState<string | null>(null);
  const [textInput, setTextInput] = useState("");

  const wsRef = useRef<WebSocket | null>(null);
  const inputAudioCtxRef = useRef<AudioContext | null>(null);
  const outputAudioCtxRef = useRef<AudioContext | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const nextStartTimeRef = useRef(0);
  const activeNodesRef = useRef<AudioBufferSourceNode[]>([]);
  const micMutedRef = useRef(micMuted);
  micMutedRef.current = micMuted;

  const cleanupAudio = useCallback(() => {
    for (const node of activeNodesRef.current) {
      try {
        node.stop();
        node.disconnect();
      } catch {
        // ignore
      }
    }
    activeNodesRef.current = [];

    if (processorRef.current) {
      try {
        processorRef.current.disconnect();
      } catch {
        // ignore
      }
      processorRef.current = null;
    }

    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }

    if (inputAudioCtxRef.current) {
      try {
        void inputAudioCtxRef.current.close();
      } catch {
        // ignore
      }
      inputAudioCtxRef.current = null;
    }

    if (outputAudioCtxRef.current) {
      try {
        void outputAudioCtxRef.current.close();
      } catch {
        // ignore
      }
      outputAudioCtxRef.current = null;
    }

    if (wsRef.current) {
      try {
        wsRef.current.close();
      } catch {
        // ignore
      }
      wsRef.current = null;
    }

    setConnected(false);
    setMicActive(false);
    setIsAiSpeaking(false);
    setMicVolume(0);
  }, []);

  const ensureOutputContext = useCallback(() => {
    if (!outputAudioCtxRef.current) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new AudioCtx({ sampleRate: 24000 });
      outputAudioCtxRef.current = ctx;
      nextStartTimeRef.current = ctx.currentTime;
    }
    if (outputAudioCtxRef.current.state === "suspended") {
      void outputAudioCtxRef.current.resume();
    }
    return outputAudioCtxRef.current;
  }, []);

  const connectWebSocket = useCallback((): Promise<WebSocket> => {
    return new Promise((resolve, reject) => {
      if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
        resolve(wsRef.current);
        return;
      }

      setConnecting(true);
      setStatus("Connecting to Nova live voice stream...");

      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const wsUrl = `${protocol}//${window.location.host}/api/live`;
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        setConnected(true);
        setConnecting(false);
        setStatus("Connected to Nova. Speak naturally.");
        resolve(ws);
      };

      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);
          if (msg.type === "ready") {
            setStatus("Nova is listening. Speak into your microphone.");
          } else if (msg.type === "audio" && msg.audio) {
            const binary = atob(msg.audio);
            const bytes = new Uint8Array(binary.length);
            for (let i = 0; i < binary.length; i++) {
              bytes[i] = binary.charCodeAt(i);
            }
            const view = new DataView(bytes.buffer);
            const float32 = new Float32Array(bytes.length / 2);
            for (let i = 0; i < float32.length; i++) {
              const int16 = view.getInt16(i * 2, true);
              float32[i] = int16 < 0 ? int16 / 0x8000 : int16 / 0x7fff;
            }

            const ctx = ensureOutputContext();
            const buffer = ctx.createBuffer(1, float32.length, 24000);
            buffer.copyToChannel(float32, 0);

            const sourceNode = ctx.createBufferSource();
            sourceNode.buffer = buffer;
            sourceNode.connect(ctx.destination);

            const now = ctx.currentTime;
            if (nextStartTimeRef.current < now) {
              nextStartTimeRef.current = now;
            }
            sourceNode.start(nextStartTimeRef.current);
            nextStartTimeRef.current += buffer.duration;
            activeNodesRef.current.push(sourceNode);
            setIsAiSpeaking(true);

            sourceNode.onended = () => {
              activeNodesRef.current = activeNodesRef.current.filter((n) => n !== sourceNode);
              if (activeNodesRef.current.length === 0) {
                setIsAiSpeaking(false);
              }
            };
          } else if (msg.type === "interrupted") {
            for (const node of activeNodesRef.current) {
              try {
                node.stop();
                node.disconnect();
              } catch {
                // ignore
              }
            }
            activeNodesRef.current = [];
            if (outputAudioCtxRef.current) {
              nextStartTimeRef.current = outputAudioCtxRef.current.currentTime;
            }
            setIsAiSpeaking(false);
            setStatus("Nova paused to listen.");
          } else if (msg.type === "transcript" && msg.text) {
            setCurrentAiTranscript((prev) => prev + msg.text);
          } else if (msg.type === "turn_complete") {
            setCurrentAiTranscript((prev) => {
              if (prev.trim()) {
                setTranscriptHistory((history) => [...history, prev.trim()]);
              }
              return "";
            });
          }
        } catch {
          // ignore
        }
      };

      ws.onerror = () => {
        setConnecting(false);
        setStatus("Could not connect to live voice.");
        reject(new Error("WebSocket error"));
      };

      ws.onclose = () => {
        setConnected(false);
        setConnecting(false);
        setStatus("Live session ended.");
      };
    });
  }, [ensureOutputContext]);

  const connectMicrophone = useCallback(async () => {
    setMicError(null);
    setStatus("Requesting microphone…");

    try {
      ensureOutputContext();
      const ws = await connectWebSocket();

      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          channelCount: 1,
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });
      streamRef.current = stream;

      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const inputCtx = new AudioCtx();
      inputAudioCtxRef.current = inputCtx;
      if (inputCtx.state === "suspended") {
        await inputCtx.resume();
      }

      const source = inputCtx.createMediaStreamSource(stream);
      const processor = inputCtx.createScriptProcessor(4096, 1, 1);
      processorRef.current = processor;

      const muteGain = inputCtx.createGain();
      muteGain.gain.value = 0;

      processor.onaudioprocess = (e) => {
        if (micMutedRef.current || ws.readyState !== WebSocket.OPEN) {
          setMicVolume(0);
          return;
        }

        const inputData = e.inputBuffer.getChannelData(0);
        let sum = 0;
        for (let i = 0; i < inputData.length; i++) {
          sum += inputData[i] * inputData[i];
        }
        const rms = Math.sqrt(sum / inputData.length);
        const volumeVal = Math.min(100, Math.round(rms * 280));
        setMicVolume(volumeVal);

        const pcm16 = downsampleTo16kHz(inputData, inputCtx.sampleRate);
        const base64 = pcmToBase64(pcm16);
        ws.send(JSON.stringify({ type: "audio", audio: base64 }));
      };

      source.connect(processor);
      processor.connect(muteGain);
      muteGain.connect(inputCtx.destination);

      setMicActive(true);
      setStatus("Microphone connected. Speak freely.");
    } catch (err: unknown) {
      const isDenied =
        err instanceof Error &&
        (err.name === "NotAllowedError" || err.name === "PermissionDeniedError");
      if (isDenied) {
        setMicError(
          "Microphone access blocked. Click the lock icon in the address bar to Allow."
        );
      } else {
        setMicError("Microphone unavailable. You can type messages below.");
      }
      setStatus("Microphone unavailable.");
    }
  }, [connectWebSocket, ensureOutputContext]);

  useEffect(() => {
    void connectMicrophone();
    return () => {
      cleanupAudio();
    };
  }, [connectMicrophone, cleanupAudio]);

  const handleSendText = () => {
    if (!textInput.trim() || !wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) return;
    const text = textInput.trim();
    wsRef.current.send(JSON.stringify({ type: "text", text }));
    setTextInput("");
    setStatus(`Sent: "${text}"`);
    ensureOutputContext();
  };

  return (
    <div className="rounded-[2.5rem] border border-cyan-400/30 bg-slate-950/80 p-6 sm:p-8 shadow-[0_24px_90px_rgba(34,211,238,0.2)] backdrop-blur-2xl text-white">
      {/* Header bar without clunky logos */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/10 pb-5">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-cyan-400/20 text-cyan-300 border border-cyan-400/30">
            <Sparkles className="h-5 w-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-[0.22em] text-cyan-300">
                Continuous Voice Conversation
              </span>
              <span
                className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[10px] font-bold border ${
                  micActive
                    ? "bg-emerald-400/20 text-emerald-300 border-emerald-400/30"
                    : "bg-amber-400/20 text-amber-300 border-amber-400/30"
                }`}
              >
                <span
                  className={`h-1.5 w-1.5 rounded-full ${
                    micActive ? "bg-emerald-400 animate-ping" : "bg-amber-400"
                  }`}
                />
                {micActive ? "Microphone Live" : "Connecting…"}
              </span>
            </div>
            <h2 className="text-lg sm:text-xl font-bold text-white">
              Real-Time Voice Assistant: Nova
            </h2>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {micActive && (
            <button
              type="button"
              onClick={() => setMicMuted(!micMuted)}
              className={`flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-xs font-bold transition cursor-pointer ${
                micMuted
                  ? "bg-rose-500/20 border border-rose-500/40 text-rose-300"
                  : "bg-white/10 border border-white/15 text-slate-200 hover:bg-white/20"
              }`}
            >
              {micMuted ? <MicOff className="h-3.5 w-3.5" /> : <Mic className="h-3.5 w-3.5" />}
              <span>{micMuted ? "Muted" : "Active"}</span>
            </button>
          )}

          <button
            type="button"
            onClick={onClose}
            className="flex items-center gap-1.5 rounded-full border border-white/15 bg-white/5 px-3.5 py-1.5 text-xs font-semibold text-slate-300 hover:bg-white/10 transition cursor-pointer"
          >
            <X className="h-3.5 w-3.5" />
            <span>Return to Console</span>
          </button>
        </div>
      </div>

      {/* Mic Warning */}
      {micError && (
        <div className="mt-4 rounded-2xl border border-rose-500/30 bg-rose-950/40 p-4 text-xs text-rose-200 flex items-start gap-3">
          <AlertCircle className="h-5 w-5 text-rose-400 shrink-0" />
          <div className="flex-1">
            <p className="font-bold text-white text-sm">Microphone Setup</p>
            <p className="text-slate-300 mt-0.5 leading-relaxed">{micError}</p>
            <button
              type="button"
              onClick={() => void connectMicrophone()}
              className="mt-2 rounded-full bg-cyan-400 px-3.5 py-1 text-xs font-bold text-slate-950 hover:bg-cyan-300 cursor-pointer"
            >
              Connect Mic
            </button>
          </div>
        </div>
      )}

      {/* Main Interactive Voice Visualizer */}
      <div className="my-8 flex flex-col items-center justify-center text-center">
        <div className="relative mb-6 flex items-center justify-center">
          <div
            className={`absolute rounded-full transition-all duration-150 ${
              isAiSpeaking
                ? "h-48 w-48 bg-cyan-400/30 blur-2xl animate-pulse"
                : micVolume > 10
                ? "h-40 w-40 bg-emerald-400/25 blur-xl"
                : "h-32 w-32 bg-cyan-400/10 blur-lg"
            }`}
          />
          <button
            type="button"
            onClick={() => {
              if (!micActive) void connectMicrophone();
            }}
            className={`relative flex h-28 w-28 items-center justify-center rounded-full border shadow-2xl transition-all duration-150 cursor-pointer ${
              isAiSpeaking
                ? "border-cyan-300 bg-cyan-950/80 shadow-[0_0_50px_rgba(34,211,238,0.5)] scale-105"
                : micVolume > 10
                ? "border-emerald-400 bg-slate-900 shadow-[0_0_35px_rgba(52,211,153,0.4)] scale-100"
                : "border-cyan-400/40 bg-slate-900 shadow-[0_0_25px_rgba(34,211,238,0.25)] hover:scale-105"
            }`}
          >
            {isAiSpeaking ? (
              <div className="flex items-center gap-1">
                <span className="h-6 w-1.5 rounded-full bg-cyan-400 animate-bounce [animation-delay:-0.4s]" />
                <span className="h-10 w-1.5 rounded-full bg-cyan-300 animate-bounce [animation-delay:-0.2s]" />
                <span className="h-8 w-1.5 rounded-full bg-cyan-200 animate-bounce [animation-delay:-0.3s]" />
                <span className="h-11 w-1.5 rounded-full bg-cyan-400 animate-bounce [animation-delay:-0.1s]" />
                <span className="h-7 w-1.5 rounded-full bg-cyan-300 animate-bounce [animation-delay:-0.25s]" />
              </div>
            ) : micVolume > 10 ? (
              <div className="flex items-center gap-1">
                <span className="h-4 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <span className="h-7 w-1.5 rounded-full bg-emerald-300 animate-pulse" />
                <span className="h-9 w-1.5 rounded-full bg-emerald-200 animate-pulse" />
                <span className="h-6 w-1.5 rounded-full bg-emerald-300 animate-pulse" />
              </div>
            ) : (
              <Mic className="h-10 w-10 text-cyan-300" />
            )}
          </button>
        </div>

        <p className="text-sm font-semibold text-white">
          {isAiSpeaking
            ? "Nova is speaking to you…"
            : micMuted
            ? "Microphone is muted."
            : micActive
            ? "Listening… Speak anytime to chat or open apps."
            : "Microphone not connected."}
        </p>
        <p className="mt-1 text-xs text-slate-400 max-w-md">{status}</p>
      </div>

      {/* Transcript Stream */}
      {(currentAiTranscript || transcriptHistory.length > 0) && (
        <div className="mt-6 rounded-2xl border border-white/10 bg-slate-900/60 p-4 max-h-[200px] overflow-y-auto space-y-2 text-xs sm:text-sm">
          {transcriptHistory.map((text, idx) => (
            <div key={idx} className="flex gap-2 text-slate-300">
              <span className="font-bold text-cyan-400 shrink-0">Nova:</span>
              <span>{text}</span>
            </div>
          ))}
          {currentAiTranscript && (
            <div className="flex gap-2 text-cyan-100">
              <span className="font-bold text-cyan-300 shrink-0">Nova:</span>
              <span className="animate-pulse">{currentAiTranscript}</span>
            </div>
          )}
        </div>
      )}

      {/* Text fallback input */}
      <div className="mt-6 flex gap-2">
        <input
          type="text"
          value={textInput}
          onChange={(e) => setTextInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSendText()}
          placeholder="Or type anything to speak with Nova…"
          className="flex-1 rounded-2xl border border-white/10 bg-slate-900 px-4 py-3 text-xs sm:text-sm text-white placeholder:text-slate-500 focus:border-cyan-400 outline-none"
        />
        <button
          type="button"
          onClick={handleSendText}
          disabled={!connected || !textInput.trim()}
          className="rounded-2xl bg-cyan-400 px-5 py-3 text-xs sm:text-sm font-bold text-slate-950 hover:bg-cyan-300 disabled:opacity-50 transition cursor-pointer flex items-center gap-1.5"
        >
          <Send className="h-4 w-4" />
          <span>Send</span>
        </button>
      </div>
    </div>
  );
}
