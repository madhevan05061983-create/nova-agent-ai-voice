import { useCallback, useEffect, useRef, useState } from "react";
import type { NovaIntent, NovaResponse } from "../lib/nova.ts";
import { resolveAppFromSpeech, AppDefinition } from "../lib/apps.ts";
import { LiveVoiceSession } from "./live-voice-session.tsx";
import { ProductivityPanel, TaskItem, NoteItem, TrackedTab } from "./productivity-panel.tsx";
import { AppLauncherModal } from "./app-launcher-modal.tsx";
import {
  Mic,
  Square,
  Send,
  Volume2,
  VolumeX,
  Copy,
  Check,
  ExternalLink,
  Sparkles,
  Grid,
  Trash2,
  RotateCcw,
} from "lucide-react";

type SpeechRecognitionAlternativeLike = {
  transcript: string;
};

type SpeechRecognitionResultLike = ArrayLike<SpeechRecognitionAlternativeLike> & {
  isFinal?: boolean;
  [index: number]: SpeechRecognitionAlternativeLike;
};

type SpeechRecognitionEventLike = {
  resultIndex: number;
  results: ArrayLike<SpeechRecognitionResultLike> & {
    [index: number]: SpeechRecognitionResultLike;
  };
};

type SpeechRecognitionInstanceLike = {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  maxAlternatives?: number;
  onstart: (() => void) | null;
  onresult: ((event: SpeechRecognitionEventLike) => void) | null;
  onerror: ((event: { error: string }) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
  abort: () => void;
};

type SpeechRecognitionConstructorLike = new () => SpeechRecognitionInstanceLike;

type WindowWithSpeech = Window & {
  SpeechRecognition?: SpeechRecognitionConstructorLike;
  webkitSpeechRecognition?: SpeechRecognitionConstructorLike;
};

export type NovaMessage = {
  id: string;
  role: "assistant" | "user";
  content: string;
  timestamp: number;
  intent?: NovaIntent;
  actionUrl?: string;
  actionLabel?: string;
};

type NovaConsoleProps = {
  displayName: string;
  onSignOut: () => void;
};

const initialAssistantMessage: NovaMessage = {
  id: "nova-welcome",
  role: "assistant",
  content:
    "Hello, I am Nova. Speak any application name to open it, manage tabs, take voice notes, set timers, or ask any question.",
  intent: "general",
  timestamp: Date.now(),
};

const CHAT_STORAGE_KEY = "nova_chat_history_v2";
const TASKS_STORAGE_KEY = "nova_tasks_v2";
const NOTES_STORAGE_KEY = "nova_notes_v2";

function loadStoredMessages(): NovaMessage[] {
  if (typeof window === "undefined") return [initialAssistantMessage];
  try {
    const raw = localStorage.getItem(CHAT_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {
    // ignore
  }
  return [initialAssistantMessage];
}

function loadStoredTasks(): TaskItem[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(TASKS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch {
    // ignore
  }
  return [
    { id: "t-1", text: "Speak 'Open Spotify' or 'Open YouTube'", completed: false, createdAt: Date.now() - 3600000 },
    { id: "t-2", text: "Try voice notes: 'Take a note review project'", completed: false, createdAt: Date.now() - 1800000 },
  ];
}

function loadStoredNotes(): NoteItem[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(NOTES_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch {
    // ignore
  }
  return [
    { id: "n-1", content: "Nova voice engine ready. Say any app name to open immediately.", createdAt: Date.now() - 7200000 },
  ];
}

function formatMessageTime(timestamp: number): string {
  try {
    return new Intl.DateTimeFormat("en-US", {
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
    }).format(new Date(timestamp));
  } catch {
    return "";
  }
}

function getSpeechRecognition(): SpeechRecognitionConstructorLike | undefined {
  if (typeof window === "undefined") return undefined;
  const speechWindow = window as WindowWithSpeech;
  return speechWindow.SpeechRecognition ?? speechWindow.webkitSpeechRecognition;
}

export function NovaConsole({ displayName, onSignOut }: NovaConsoleProps) {
  const [messages, setMessages] = useState<NovaMessage[]>(loadStoredMessages);
  const [draft, setDraft] = useState("");
  const [suggestions, setSuggestions] = useState<string[]>([
    "Open YouTube",
    "Open Spotify",
    "Open WhatsApp",
    "Open Netflix",
    "Close tabs",
    "What time is it?",
  ]);
  const [status, setStatus] = useState("Ready. Speak any app name or command.");
  const [listening, setListening] = useState(false);
  const [sending, setSending] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [autoSpeak, setAutoSpeak] = useState(true);
  const [speechRate, setSpeechRate] = useState(1);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [selectedVoiceName, setSelectedVoiceName] = useState<string>("");
  const [micPermissionError, setMicPermissionError] = useState<string | null>(null);
  const [liveMode, setLiveMode] = useState(false);
  const [isAppLauncherOpen, setIsAppLauncherOpen] = useState(false);
  const [lastLaunchedApp, setLastLaunchedApp] = useState<{ name: string; url: string } | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Productivity states
  const [tasks, setTasks] = useState<TaskItem[]>(loadStoredTasks);
  const [notes, setNotes] = useState<NoteItem[]>(loadStoredNotes);
  const [activeTimerDuration, setActiveTimerDuration] = useState<number | null>(null);

  // Tab tracking
  const [activeTabs, setActiveTabs] = useState<TrackedTab[]>([]);
  const openedTabsRef = useRef<Map<string, Window>>(new Map());

  const activeRecognitionRef = useRef<SpeechRecognitionInstanceLike | null>(null);
  const pendingTranscriptRef = useRef("");
  const autoSpeakRef = useRef(autoSpeak);
  autoSpeakRef.current = autoSpeak;
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  // Persistence
  useEffect(() => {
    try {
      localStorage.setItem(CHAT_STORAGE_KEY, JSON.stringify(messages));
    } catch {
      // ignore
    }
  }, [messages]);

  useEffect(() => {
    try {
      localStorage.setItem(TASKS_STORAGE_KEY, JSON.stringify(tasks));
    } catch {
      // ignore
    }
  }, [tasks]);

  useEffect(() => {
    try {
      localStorage.setItem(NOTES_STORAGE_KEY, JSON.stringify(notes));
    } catch {
      // ignore
    }
  }, [notes]);

  const scrollToBottom = useCallback((smooth = true) => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: smooth ? "smooth" : "auto" });
    }
  }, []);

  useEffect(() => {
    scrollToBottom(true);
  }, [messages, scrollToBottom]);

  // Load available speech synthesis voices
  useEffect(() => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;

    const updateVoices = () => {
      const available = window.speechSynthesis.getVoices();
      if (available.length > 0) {
        setVoices(available);
        const bestVoice =
          available.find(
            (v) =>
              v.lang.startsWith("en") &&
              (v.name.includes("Google") || v.name.includes("Natural") || v.name.includes("Samantha"))
          ) ||
          available.find((v) => v.lang.startsWith("en")) ||
          available[0];
        if (bestVoice && !selectedVoiceName) {
          setSelectedVoiceName(bestVoice.name);
        }
      }
    };

    updateVoices();
    window.speechSynthesis.onvoiceschanged = updateVoices;
    return () => {
      if (typeof window !== "undefined" && "speechSynthesis" in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, [selectedVoiceName]);

  // Reliable Speech Synthesis Method
  const speakText = useCallback(
    (textToSpeak: string, shouldSignOut = false) => {
      if (typeof window === "undefined" || !("speechSynthesis" in window)) {
        if (shouldSignOut) onSignOut();
        return;
      }

      try {
        window.speechSynthesis.cancel();
        if (window.speechSynthesis.paused) {
          window.speechSynthesis.resume();
        }

        const utterance = new SpeechSynthesisUtterance(textToSpeak);
        utterance.lang = "en-US";
        utterance.rate = speechRate;
        utterance.pitch = 1.0;

        if (selectedVoiceName && voices.length > 0) {
          const matchedVoice = voices.find((v) => v.name === selectedVoiceName);
          if (matchedVoice) utterance.voice = matchedVoice;
        }

        utterance.onstart = () => setIsSpeaking(true);
        utterance.onend = () => {
          setIsSpeaking(false);
          if (shouldSignOut) onSignOut();
        };
        utterance.onerror = () => {
          setIsSpeaking(false);
          if (shouldSignOut) onSignOut();
        };

        setTimeout(() => {
          window.speechSynthesis.speak(utterance);
        }, 30);
      } catch {
        setIsSpeaking(false);
        if (shouldSignOut) onSignOut();
      }
    },
    [onSignOut, speechRate, selectedVoiceName, voices]
  );

  const stopSpeaking = useCallback(() => {
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  }, []);

  // Launch Web App Helper
  const launchUrl = useCallback((url: string, label: string) => {
    try {
      const win = window.open(url, "_blank");
      const tabId = crypto.randomUUID();
      if (win) {
        openedTabsRef.current.set(tabId, win);
      }
      setActiveTabs((prev) => [
        ...prev,
        {
          id: tabId,
          url,
          label: label || "Web Tab",
          openedAt: Date.now(),
        },
      ]);
      setLastLaunchedApp({ name: label, url });
      setStatus(`Opened ${label}.`);
    } catch {
      // Popup blocker fallback
      setLastLaunchedApp({ name: label, url });
    }
  }, []);

  // Close tab operations
  const closeTabs = useCallback(
    (target: string = "all") => {
      let closedCount = 0;
      if (target === "all") {
        openedTabsRef.current.forEach((win) => {
          if (win && !win.closed) {
            try {
              win.close();
              closedCount++;
            } catch {
              // ignore
            }
          }
        });
        openedTabsRef.current.clear();
        setActiveTabs([]);
        const msg = closedCount > 0 ? `Closed ${closedCount} opened browser tab(s).` : "No active opened tabs to close.";
        setStatus(msg);
        return msg;
      } else if (target === "last") {
        const keys = Array.from(openedTabsRef.current.keys());
        const lastKey = keys[keys.length - 1];
        if (lastKey) {
          const win = openedTabsRef.current.get(lastKey);
          if (win && !win.closed) {
            try {
              win.close();
              closedCount++;
            } catch {
              // ignore
            }
          }
          openedTabsRef.current.delete(lastKey);
          setActiveTabs((prev) => prev.filter((t) => t.id !== lastKey));
          setStatus("Closed last opened tab.");
          return "Closed last opened tab.";
        }
        return "No tab to close.";
      } else {
        const toRemove: string[] = [];
        openedTabsRef.current.forEach((win, id) => {
          const tab = activeTabs.find((t) => t.id === id);
          if (
            tab &&
            (tab.label.toLowerCase().includes(target.toLowerCase()) ||
              tab.url.toLowerCase().includes(target.toLowerCase()))
          ) {
            if (win && !win.closed) {
              try {
                win.close();
                closedCount++;
              } catch {
                // ignore
              }
            }
            toRemove.push(id);
          }
        });
        toRemove.forEach((id) => openedTabsRef.current.delete(id));
        setActiveTabs((prev) => prev.filter((t) => !toRemove.includes(t.id)));
        const msg = closedCount > 0 ? `Closed ${target} tab.` : `No active ${target} tab found.`;
        setStatus(msg);
        return msg;
      }
    },
    [activeTabs]
  );

  const closeSingleTab = useCallback((tabId: string) => {
    const win = openedTabsRef.current.get(tabId);
    if (win && !win.closed) {
      try {
        win.close();
      } catch {
        // ignore
      }
    }
    openedTabsRef.current.delete(tabId);
    setActiveTabs((prev) => prev.filter((t) => t.id !== tabId));
    setStatus("Closed tab.");
  }, []);

  // Tasks handlers
  const handleAddTask = useCallback((text: string) => {
    const newTask: TaskItem = {
      id: crypto.randomUUID(),
      text,
      completed: false,
      createdAt: Date.now(),
    };
    setTasks((prev) => [newTask, ...prev]);
    setStatus(`Task added: "${text}"`);
  }, []);

  const handleToggleTask = useCallback((id: string) => {
    setTasks((prev) =>
      prev.map((t) => (t.id === id ? { ...t, completed: !t.completed } : t))
    );
  }, []);

  const handleDeleteTask = useCallback((id: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const handleClearTasks = useCallback(() => {
    setTasks([]);
    setStatus("Checklist cleared.");
  }, []);

  // Notes handlers
  const handleAddNote = useCallback((content: string) => {
    const newNote: NoteItem = {
      id: crypto.randomUUID(),
      content,
      createdAt: Date.now(),
    };
    setNotes((prev) => [newNote, ...prev]);
    setStatus(`Saved note.`);
  }, []);

  const handleDeleteNote = useCallback((id: string) => {
    setNotes((prev) => prev.filter((n) => n.id !== id));
  }, []);

  const handleClearNotes = useCallback(() => {
    setNotes([]);
    setStatus("Notes cleared.");
  }, []);

  // Main Submit Pipeline
  const submitTranscript = useCallback(
    async (transcript: string) => {
      const cleanTranscript = transcript.trim();
      if (!cleanTranscript || sending) return;

      const userMsg: NovaMessage = {
        id: crypto.randomUUID(),
        role: "user",
        content: cleanTranscript,
        timestamp: Date.now(),
      };
      setMessages((current) => [...current, userMsg]);
      setDraft("");
      setSending(true);
      setStatus("Processing voice command…");

      try {
        // Fast local app check for immediate responsiveness
        const localApp = resolveAppFromSpeech(cleanTranscript);
        if (localApp) {
          launchUrl(localApp.url, localApp.name);
          const reply = `Opening ${localApp.name} in a new tab.`;
          const assistantMessage: NovaMessage = {
            id: crypto.randomUUID(),
            role: "assistant",
            content: reply,
            timestamp: Date.now(),
            intent: "open_tab",
            actionUrl: localApp.url,
            actionLabel: localApp.name,
          };
          setMessages((current) => [...current, assistantMessage]);
          setSuggestions([
            `Close ${localApp.name}`,
            "Close all tabs",
            "Take a note",
            "What time is it?",
          ]);
          setStatus(`Opened ${localApp.name}.`);
          if (autoSpeakRef.current) speakText(reply);
          setSending(false);
          return;
        }

        const token = typeof window !== "undefined" ? localStorage.getItem("nova_session_id") : null;
        const headers: Record<string, string> = { "Content-Type": "application/json" };
        if (token) headers["Authorization"] = `Bearer ${token}`;

        const response = await fetch("/api/nova", {
          method: "POST",
          headers,
          body: JSON.stringify({ transcript: cleanTranscript }),
        });

        if (!response.ok) {
          const error = (await response.json().catch(() => null)) as { error?: string } | null;
          throw new Error(error?.error ?? "Service unavailable.");
        }

        const data = (await response.json()) as NovaResponse;
        const action = data.action;

        // Process action side effects
        if (action) {
          if (action.type === "open_url") {
            launchUrl(action.url, action.label || "Web Tab");
          } else if (action.type === "close_tabs") {
            closeTabs(action.target || "all");
          } else if (action.type === "create_note") {
            handleAddNote(action.content);
          } else if (action.type === "clear_notes") {
            handleClearNotes();
          } else if (action.type === "add_task") {
            handleAddTask(action.text);
          } else if (action.type === "complete_task") {
            if (action.text) {
              setTasks((prev) =>
                prev.map((t) =>
                  t.text.toLowerCase().includes(action.text!.toLowerCase())
                    ? { ...t, completed: true }
                    : t
                )
              );
            }
          } else if (action.type === "clear_tasks") {
            handleClearTasks();
          } else if (action.type === "set_timer") {
            setActiveTimerDuration(action.seconds);
          }
        }

        const assistantMessage: NovaMessage = {
          id: crypto.randomUUID(),
          role: "assistant",
          content: data.reply,
          timestamp: Date.now(),
          intent: data.intent,
          actionUrl: action && action.type === "open_url" ? action.url : undefined,
          actionLabel: action && action.type === "open_url" ? action.label || action.url : undefined,
        };

        setMessages((current) => [...current, assistantMessage]);
        setSuggestions(
          data.suggestions.length > 0
            ? data.suggestions
            : ["Open Spotify", "Close tabs", "Take a note", "What time is it?"]
        );

        setStatus(
          data.intent === "sign_out"
            ? "Signing you out securely."
            : action?.type === "open_url"
            ? `Opened ${action.label || "app"}.`
            : "Nova answered."
        );

        if (autoSpeakRef.current || data.intent === "sign_out") {
          speakText(data.reply, data.intent === "sign_out");
        }
      } catch (error) {
        const message = error instanceof Error ? error.message : "Unexpected error.";
        setStatus(message);
        setMessages((current) => [
          ...current,
          {
            id: crypto.randomUUID(),
            role: "assistant",
            content: message,
            timestamp: Date.now(),
            intent: "general",
          },
        ]);
        if (autoSpeakRef.current) speakText(message);
      } finally {
        setSending(false);
      }
    },
    [sending, launchUrl, closeTabs, handleAddNote, handleClearNotes, handleAddTask, handleClearTasks, speakText]
  );

  // Stop recognition on unmount
  useEffect(() => {
    return () => {
      if (activeRecognitionRef.current) {
        try {
          activeRecognitionRef.current.abort();
        } catch {
          // ignore
        }
        activeRecognitionRef.current = null;
      }
    };
  }, []);

  // Speech Recognition
  const startListening = useCallback(async () => {
    stopSpeaking();
    setMicPermissionError(null);

    const Recognition = getSpeechRecognition();
    if (!Recognition) {
      setMicPermissionError(
        "Speech recognition is not supported in this browser. Please use Chrome, Edge, or Safari, or type your message below."
      );
      setStatus("Microphone not supported.");
      return;
    }

    if (activeRecognitionRef.current) {
      try {
        activeRecognitionRef.current.abort();
      } catch {
        // ignore
      }
      activeRecognitionRef.current = null;
    }

    try {
      const recognition = new Recognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = typeof navigator !== "undefined" && navigator.language ? navigator.language : "en-US";
      recognition.maxAlternatives = 1;

      recognition.onstart = () => {
        setListening(true);
        setStatus("Listening… Speak any app name (e.g. 'Spotify', 'YouTube') or question.");
      };

      recognition.onresult = (event) => {
        let finalTranscript = "";
        let interimTranscript = "";

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          const res = event.results[i];
          if (res.isFinal) finalTranscript += res[0].transcript;
          else interimTranscript += res[0].transcript;
        }

        const currentText = (finalTranscript || interimTranscript).trim();
        if (currentText) {
          pendingTranscriptRef.current = currentText;
          setDraft(currentText);
          setStatus(`Heard: “${currentText}”`);
        }
      };

      recognition.onerror = (event) => {
        setListening(false);
        if (event.error === "no-speech") {
          setStatus("No speech heard. Tap the mic and speak clearly.");
        } else if (event.error === "not-allowed" || event.error === "service-not-allowed") {
          setMicPermissionError(
            "Microphone access blocked. Click the lock/microphone icon in the address bar to Allow."
          );
          setStatus("Microphone permission blocked.");
        } else {
          setStatus(`Microphone note: ${event.error}. You can also type below.`);
        }
      };

      recognition.onend = () => {
        setListening(false);
        const textToSubmit = pendingTranscriptRef.current.trim();
        pendingTranscriptRef.current = "";
        if (textToSubmit) {
          void submitTranscript(textToSubmit);
        }
      };

      activeRecognitionRef.current = recognition;
      pendingTranscriptRef.current = "";
      recognition.start();
    } catch {
      setListening(false);
      setStatus("Could not start microphone.");
    }
  }, [stopSpeaking, submitTranscript]);

  const stopListening = useCallback(() => {
    if (activeRecognitionRef.current) {
      try {
        activeRecognitionRef.current.stop();
      } catch {
        // ignore
      }
    }
    setListening(false);
  }, []);

  const handleSend = useCallback(() => {
    const transcript = draft.trim();
    if (!transcript) return;
    void submitTranscript(transcript);
  }, [draft, submitTranscript]);

  const clearChatHistory = useCallback(() => {
    const reset = [initialAssistantMessage];
    setMessages(reset);
    try {
      localStorage.setItem(CHAT_STORAGE_KEY, JSON.stringify(reset));
    } catch {
      // ignore
    }
    setStatus("Conversation reset.");
  }, []);

  const handleCopyMessage = useCallback((id: string, text: string) => {
    try {
      navigator.clipboard.writeText(text);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 1800);
    } catch {
      // ignore
    }
  }, []);

  if (liveMode) {
    return <LiveVoiceSession displayName={displayName} onClose={() => setLiveMode(false)} />;
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[1.18fr_0.82fr]">
      {/* LEFT COLUMN: Voice Conversation Console */}
      <div className="flex flex-col rounded-[2.5rem] border border-white/10 bg-slate-950/75 p-6 sm:p-7 shadow-[0_24px_80px_rgba(0,0,0,0.5)] backdrop-blur-xl">
        {/* Header bar */}
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/10 pb-5">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-[0.24em] text-cyan-300">Nova Voice Console</span>
              {isSpeaking && (
                <span className="inline-flex items-center gap-1.5 rounded-full bg-cyan-400/20 px-2.5 py-0.5 text-[11px] font-semibold text-cyan-300 border border-cyan-400/30">
                  <span className="h-1.5 w-1.5 rounded-full bg-cyan-400 animate-ping" />
                  Speaking
                </span>
              )}
            </div>
            <h2 className="mt-1 text-2xl font-bold text-white">Welcome, {displayName}</h2>
            <div className="flex items-center gap-2 mt-0.5">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
              <span className="text-xs text-slate-300">Active Operator Session</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setIsAppLauncherOpen(true)}
              className="inline-flex items-center gap-1.5 rounded-full bg-cyan-400/20 border border-cyan-400/30 px-3.5 py-2 text-xs font-bold text-cyan-300 hover:bg-cyan-400/30 transition cursor-pointer shadow-sm active:scale-95"
            >
              <Grid className="h-3.5 w-3.5" />
              <span>App Hub (120+)</span>
            </button>

            <button
              type="button"
              onClick={() => setLiveMode(true)}
              className="inline-flex items-center gap-1.5 rounded-full bg-cyan-400 px-4 py-2 text-xs font-bold text-slate-950 hover:bg-cyan-300 transition cursor-pointer shadow-md shadow-cyan-400/25 active:scale-95"
            >
              <Sparkles className="h-3.5 w-3.5" />
              <span>Continuous Live Voice</span>
            </button>
          </div>
        </div>

        {/* Fallback Banner for Opened App (Guarantees Popup Unblock) */}
        {lastLaunchedApp && (
          <div className="mt-4 flex items-center justify-between rounded-2xl border border-cyan-400/30 bg-cyan-950/40 px-4 py-2.5 text-xs text-cyan-100 animate-in fade-in">
            <div className="flex items-center gap-2">
              <span className="text-base">🚀</span>
              <span>
                Launched <strong>{lastLaunchedApp.name}</strong>. If popup was blocked:
              </span>
            </div>
            <a
              href={lastLaunchedApp.url}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 rounded-lg bg-cyan-400 px-3 py-1 font-bold text-slate-950 hover:bg-cyan-300 transition"
            >
              <span>Open Tab</span>
              <ExternalLink className="h-3 w-3" />
            </a>
          </div>
        )}

        {/* Mic Permission Guidance */}
        {micPermissionError && (
          <div className="mt-4 rounded-2xl border border-rose-500/30 bg-rose-950/40 p-4 text-xs text-rose-200 shadow-lg">
            <p className="font-bold text-white text-sm">Microphone Notice</p>
            <p className="text-slate-300 mt-1 leading-relaxed">{micPermissionError}</p>
            <div className="mt-2 flex gap-2">
              <button
                type="button"
                onClick={() => {
                  setMicPermissionError(null);
                  void startListening();
                }}
                className="rounded-full bg-cyan-400 px-3.5 py-1.5 font-bold text-slate-950 hover:bg-cyan-300 cursor-pointer"
              >
                Try Again
              </button>
              <button
                type="button"
                onClick={() => setMicPermissionError(null)}
                className="rounded-full bg-white/10 px-3 py-1.5 text-slate-300 hover:bg-white/20 cursor-pointer"
              >
                Dismiss
              </button>
            </div>
          </div>
        )}

        {/* Action Controls: Mic button, Send button, Status */}
        <div className="mt-6 flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={listening ? stopListening : startListening}
            className={`inline-flex items-center gap-2.5 rounded-full px-6 py-3.5 text-sm font-bold transition shadow-lg cursor-pointer ${
              listening
                ? "bg-rose-500 text-white animate-pulse shadow-rose-500/30"
                : "bg-cyan-400 text-slate-950 hover:bg-cyan-300 shadow-cyan-400/25 active:scale-95"
            }`}
          >
            {listening ? <Square className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
            <span>{listening ? "Stop Listening" : "Tap to Speak Any App"}</span>
          </button>

          <button
            type="button"
            onClick={handleSend}
            disabled={sending || !draft.trim()}
            className="inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-white/10 px-5 py-3.5 text-sm font-semibold text-white transition hover:bg-white/15 disabled:opacity-40 cursor-pointer"
          >
            <Send className="h-4 w-4" />
            <span>{sending ? "Processing…" : "Send"}</span>
          </button>

          <div className="flex items-center gap-2 text-xs text-slate-300">
            {isSpeaking && (
              <div className="flex items-center gap-0.5">
                <span className="h-3 w-1 bg-cyan-400 rounded-full animate-bounce [animation-delay:-0.3s]" />
                <span className="h-4 w-1 bg-cyan-400 rounded-full animate-bounce [animation-delay:-0.15s]" />
                <span className="h-5 w-1 bg-cyan-400 rounded-full animate-bounce" />
                <span className="h-3 w-1 bg-cyan-400 rounded-full animate-bounce [animation-delay:-0.2s]" />
              </div>
            )}
            <span className="truncate max-w-xs">{status}</span>
          </div>
        </div>

        {/* Spoken/Written Command Input */}
        <label className="mt-4 block">
          <span className="mb-2 block text-xs font-semibold uppercase tracking-wider text-slate-300">
            Spoken / Written Command
          </span>
          <textarea
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            rows={2}
            placeholder="Speak any app name ('Spotify', 'WhatsApp', 'YouTube') or type a task..."
            className="w-full rounded-2xl border border-white/10 bg-slate-900/90 px-4 py-2.5 text-sm text-white outline-none transition placeholder:text-slate-500 focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400"
          />
        </label>

        {/* Suggestion Quick Action Pills */}
        <div className="mt-3 flex flex-wrap gap-2">
          {suggestions.map((action: string) => (
            <button
              key={action}
              type="button"
              onClick={() => {
                setDraft(action);
                void submitTranscript(action);
              }}
              className="rounded-full border border-cyan-400/25 bg-cyan-400/5 px-3 py-1.5 text-xs font-medium text-cyan-200 transition hover:border-cyan-400 hover:bg-cyan-400/15 cursor-pointer"
            >
              💬 {action}
            </button>
          ))}
        </div>

        {/* Scrollable Message List Header */}
        <div className="mt-6 flex items-center justify-between border-t border-white/10 pt-4 pb-2">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
              Dialogue Log
            </span>
            <span className="rounded-full bg-cyan-400/15 px-2 py-0.5 text-[10px] font-semibold text-cyan-300 border border-cyan-400/20">
              {messages.length}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={clearChatHistory}
              className="rounded-lg px-2.5 py-1 text-[11px] text-slate-400 hover:text-rose-300 transition cursor-pointer flex items-center gap-1"
            >
              <Trash2 className="h-3 w-3" />
              <span>Reset</span>
            </button>
          </div>
        </div>

        {/* Scrollable Message List */}
        <div className="mt-2 space-y-3.5 max-h-[380px] overflow-y-auto pr-2 custom-scrollbar flex-1">
          {messages.map((message) => {
            const isUser = message.role === "user";
            return (
              <article
                key={message.id}
                className={`rounded-2xl border p-4 text-sm leading-relaxed transition ${
                  isUser
                    ? "border-white/10 bg-white/5 text-slate-100 ml-6"
                    : "border-cyan-400/25 bg-cyan-950/20 text-cyan-50 mr-6 shadow-sm"
                }`}
              >
                <div className="mb-2 flex items-center justify-between border-b border-white/5 pb-1.5">
                  <div className="flex items-center gap-2">
                    <span
                      className={`inline-flex items-center rounded-md px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider ${
                        isUser
                          ? "bg-slate-800 text-slate-300 border border-slate-700"
                          : "bg-cyan-400/20 text-cyan-300 border border-cyan-400/30"
                      }`}
                    >
                      {isUser ? "You" : "Nova"}
                    </span>
                    <span className="text-[11px] text-slate-400">
                      {formatMessageTime(message.timestamp)}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    {message.actionUrl && (
                      <a
                        href={message.actionUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="rounded bg-cyan-400/20 px-2 py-0.5 text-[11px] font-semibold text-cyan-300 hover:bg-cyan-400/30 transition flex items-center gap-1"
                      >
                        <span>Open {message.actionLabel || "Tab"}</span>
                        <ExternalLink className="h-3 w-3" />
                      </a>
                    )}
                    <button
                      type="button"
                      onClick={() => handleCopyMessage(message.id, message.content)}
                      className="rounded px-2 py-0.5 text-xs text-slate-400 hover:bg-white/10 hover:text-white transition cursor-pointer"
                    >
                      {copiedId === message.id ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                    </button>
                    <button
                      type="button"
                      onClick={() => speakText(message.content)}
                      className="rounded px-2 py-0.5 text-xs text-slate-400 hover:bg-white/10 hover:text-cyan-300 transition flex items-center gap-1 cursor-pointer"
                      title="Speak response"
                    >
                      <Volume2 className="h-3 w-3" />
                    </button>
                  </div>
                </div>
                <p className="whitespace-pre-wrap">{message.content}</p>
              </article>
            );
          })}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* RIGHT COLUMN: Productivity Panel, App Launcher, Audio Controls */}
      <div className="space-y-5 flex flex-col">
        {/* Productivity Center */}
        <div className="flex-1">
          <ProductivityPanel
            tasks={tasks}
            notes={notes}
            activeTabs={activeTabs}
            onAddTask={handleAddTask}
            onToggleTask={handleToggleTask}
            onDeleteTask={handleDeleteTask}
            onClearTasks={handleClearTasks}
            onAddNote={handleAddNote}
            onDeleteNote={handleDeleteNote}
            onClearNotes={handleClearNotes}
            onCloseTab={closeSingleTab}
            onCloseAllTabs={() => closeTabs("all")}
            onSpeak={(text) => speakText(text)}
            activeTimerDuration={activeTimerDuration}
            onTimerComplete={() => setActiveTimerDuration(null)}
          />
        </div>

        {/* Audio Output Preferences Box */}
        <div className="rounded-[2rem] border border-white/10 bg-slate-900/70 backdrop-blur-xl p-5 text-white shadow-lg space-y-3.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-cyan-300">
              Speech Output
            </span>
            <button
              type="button"
              onClick={() => setAutoSpeak(!autoSpeak)}
              className={`flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-bold transition cursor-pointer ${
                autoSpeak ? "bg-cyan-400 text-slate-950" : "bg-white/10 text-slate-400"
              }`}
            >
              {autoSpeak ? <Volume2 className="h-3.5 w-3.5" /> : <VolumeX className="h-3.5 w-3.5" />}
              <span>{autoSpeak ? "Auto-Speak ON" : "Muted"}</span>
            </button>
          </div>

          {/* Voice rate */}
          <div className="flex items-center justify-between text-xs text-slate-300">
            <span>Speech Speed:</span>
            <div className="flex gap-1.5">
              {[0.9, 1.0, 1.15, 1.3].map((rate) => (
                <button
                  key={rate}
                  type="button"
                  onClick={() => setSpeechRate(rate)}
                  className={`rounded-lg px-2.5 py-0.5 text-xs font-semibold transition cursor-pointer ${
                    speechRate === rate
                      ? "bg-cyan-400 text-slate-950"
                      : "bg-white/5 border border-white/10 text-slate-300 hover:bg-white/10"
                  }`}
                >
                  {rate}x
                </button>
              ))}
            </div>
          </div>

          {/* Voice selection */}
          {voices.length > 0 && (
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Synthesizer Voice</label>
              <select
                value={selectedVoiceName}
                onChange={(e) => setSelectedVoiceName(e.target.value)}
                className="w-full rounded-xl border border-white/10 bg-slate-950 px-3 py-1.5 text-xs text-slate-200 outline-none focus:border-cyan-400 cursor-pointer"
              >
                {voices
                  .filter((v) => v.lang.startsWith("en"))
                  .slice(0, 15)
                  .map((v) => (
                    <option key={v.name} value={v.name}>
                      {v.name} ({v.lang})
                    </option>
                  ))}
              </select>
            </div>
          )}
        </div>
      </div>

      {/* 120+ App Directory Modal */}
      <AppLauncherModal
        isOpen={isAppLauncherOpen}
        onClose={() => setIsAppLauncherOpen(false)}
        onOpenApp={(app: AppDefinition) => {
          launchUrl(app.url, app.name);
          const reply = `Opening ${app.name} in a new tab.`;
          speakText(reply);
        }}
      />
    </div>
  );
}
